const cod = document.querySelectorAll('.cod-field');

cod[0].focus();

cod.forEach((field, index) => {
    field.addEventListener('keydown', (e) => {
        if (e.key >= 0 && e.key <= 9) {
            cod[index].value = "";
            setTimeout(() => {
                cod[index + 1].focus();
            }, 4);
        }
        else if (e.key === 'Backspace') {
            setTimeout(() => {
                cod[index - 1].focus();
            }, 4);
        }
    })
})
