<?php
include('conexao/conexao.php');
//Recebendo os números inseridos
$codigo = $_SESSION['codigoUSER'];
if (isset($_POST["Verificar"])) {

    $cod1 = $_POST['cod1'];
    $cod2 = $_POST['cod2'];
    $cod3 = $_POST['cod3'];
    $cod4 = $_POST['cod4'];
    //Recendo o id e o código gerado para o usuário
    //Código inserido pelo usuário
    $codInserido = $cod1 . $cod2 . $cod3 . $cod4;

    if (!empty($codInserido)) {
        // Checa se o código inserido é igual ao código gerado
        if ($codInserido == $codigo) {
            //echo $codigo;
            $errorOK = "success";
            $_SESSION["OK"] = $errorOK;
            $Ok = $_SESSION["OK"];
            header("location: cadastro-step-Verif.php?Ok=$Ok");
        } else {
            $errorFAIL = "Código errado!";
        }
    } else {
        $errorFAIL = "Insira o código completo.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificar EMAIL</title>
</head>
<style>
    .cod-field {
        border-radius: 5px;
        border: 3px solid #cacaca;
        outline: none;
    }

    .cod-field::-webkit-inner-spin-button,
    .cod-field::-webkit-outer-spin-button {
        -webkit-appearance: none;

    }

    .cod-field:valid {
        border-color: #4D3F8F;
        box-shadow: 0px 10px 10px -5px rgba(0, 0, 0, 0.25);
    }
</style>

<body>
    <div>
        <img src="mailer/depositphotos_555089554-stock-illustration-happy-emoji-emoticon-showing-double.jpg" alt="HEHE" height="100px" width="100px">
    </div>
    <h1>Foi enviado uma mensagem para seu email, verifique sua caixa de entrada: <? $email ?> </h1>
    <h1>e digite o código solicitado:</h1>
    <form action="" method="post" autocomplete="off" class="fields-input">
        <input type="number" name="cod1" class="cod-field" placeholder="0" min="0" max="9" required onpaste="false">
        <input type="number" name="cod2" class="cod-field" placeholder="0" min="0" max="9" required onpaste="false">
        <input type="number" name="cod3" class="cod-field" placeholder="0" min="0" max="9" required onpaste="false">
        <input type="number" name="cod4" class="cod-field" placeholder="0" min="0" max="9" required onpaste="false">
        <div class="submit">
            <input type="submit" name="Verificar" value="Verificar" class="button">
        </div>
    </form>

    <p><?php
        if (isset($errorFAIL)) {
            echo $errorFAIL;
        }
        ?></p>


    <script src="js/verif.js"></script>
</body>

</html>