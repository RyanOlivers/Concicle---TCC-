
var menu = document.getElementById("menu");

window.addEventListener("scroll", function () {
  if (window.pageYOffset > (window.innerHeight * 0.1)) {
    menu.classList.add("hide-menu");
  } else {
    menu.classList.remove("hide-menu");
  }
});

// Verificar a posição inicial da janela e ocultar o menu, se necessário
if (window.pageYOffset > (window.innerHeight * 0.01)) {
  menu.classList.add("hide-menu");
}

menu.addEventListener("mouseenter", function () {
  menu.classList.remove("hide-menu");
});

menu.addEventListener("mouseleave", function () {
  if (window.pageYOffset > (window.innerHeight * 0.01)) {
    menu.classList.add("hide-menu");
  }
});
window.addEventListener("scroll", function () {
  if (window.pageYOffset > (window.innerHeight * 0.01)) { /* 10vh corresponde a 10% da altura da janela de visualização */
    menu.classList.add("dark");
  } else {
    menu.classList.remove("dark");
  }
});

  var stars = document.querySelectorAll('.star-icon');

  document.addEventListener('DOMContentLoaded', function() {
    var stars = document.querySelectorAll('.star-icon');

    stars.forEach(function(star) {
      star.addEventListener('click', function() {
        stars.forEach(function(sibling) {
          sibling.classList.remove('ativo');
        });
        this.classList.add('ativo');
        console.log(this.getAttribute('data-avaliacao'));
      });
    });
  });

// Obtém os elementos checkboxes e a div
const checkboxes = document.querySelectorAll(".meusCheckboxes");
const div = document.getElementById("prod-img");

// Adiciona um ouvinte de evento para cada checkbox
checkboxes.forEach(checkbox => {
  checkbox.addEventListener("change", function () {
    // Obtém o ID da checkbox clicada
    const checkboxId = this.id;

    // Define o caminho da imagem com base no ID da checkbox clicada
    let imagePath;
    if (checkboxId === "item-1") {
      imagePath = "img/paper bin.png";
    } else if (checkboxId === "item-2") {
      imagePath = "img/BG.png";
    } else if (checkboxId === "item-3") {
      imagePath = "img/png.png";
    } else if (checkboxId === "item-4") {
      imagePath = "img/recycling-animate.svg";
    }

    // Atualiza o src da imagem na div
    document.getElementById("minhaImagem").src = imagePath;
  });
});