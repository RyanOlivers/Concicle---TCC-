<?php


include('conexao/conexao.php');

if (isset($_POST['email']) || isset($_POST['senha'])) {

    $email = $conn->real_escape_string($_POST['email']);
    $senha = $_POST['senha'];

    $sql_code = "SELECT * FROM usuario WHERE email = '$email'";
    $sql_query = $conn->query($sql_code) or die("Falha na execução do código SQL: " . $conn->error);

    $usuario = $sql_query->fetch_assoc();

    if (password_verify($senha, $usuario['senha'])) {

    }


}

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/menu.css">

    <title> CONCICLE | Login</title>
</head>

<body>
    <div id="container">
        <nav>
            <ul class="a">
                <li class="logotipo">
                    <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li class="li-pai">
                            <?php
                            if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
                                echo "<p class='dropdown-arrow'>" . $_SESSION['nome'] . "</p>";
                                ?>
                                <ul class='sub-menus'>
                                    <li class="perfil-area">
                                        <a href="">
                                            <img src="img/user-green.svg" alt="">
                                            <div class="sub-text">
                                                <p class="p-ola"> Olá </p>
                                                <p class="p-name">
                                                    <?= $_SESSION['nome'] ?>
                                                </p>
                                            </div>
                                        </a>
                                    </li>
                                    <li class="dados">
                                        <a href='perfil.php'>
                                            <img src="img/user.svg" alt="" srcset="">
                                            <p>Meu perfil</p>
                                        </a>
                                        <a href='http://'>
                                            <img src="img/heart.svg" alt="" srcset="">
                                            <p>Favoritos </p>
                                        </a>
                                        <a href='http://'>
                                            <img src="img/bag.svg" alt="" srcset="">
                                            <p>Histórico/Compras</p>
                                        </a>
                                    </li>
                                    <li class="dados">
                                        <a href='http://'> <img src="img/tag.svg" alt="" srcset="">
                                            <p>Vender</p>
                                        </a>
                                    </li>
                                    <li class="dados">
                                        <a href='http://'> <img src="img/faq.svg" alt="" srcset="">
                                            <p>Perguntas</p>
                                        </a>
                                    </li>
                                    <li class="dados">
                                        <a href='logout.php'> <img src="img/logout.svg" alt="" srcset="">
                                            <p>sair</p>
                                        </a>
                                    </li>
                                </ul>

                                <?php
                            } else {
                                echo "<a href='login.php' class='cursor'>Login</a>";
                            }
                            ?>
                        </li>
                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <main class="bg">
            <section class="login">
                <header class="header-login">
                    <h1> Conscientize, Recicle & Receba </h1>
                    <h2> Faça parte dessa equipe e mude o mundo! </h2>
                </header>

                <form action="" method="post">
                    <main class="main-login">
                        <section class="card-login">
                            <h1> Entre na sua conta </h1>

                            <div class="textfield">
                                <label for="email"> E-mail </label>
                                <input type="email" name="email" placeholder="E-mail@exemplo.com">
                            </div>

                            <div class="textfield">
                                <label for="senha"> Senha* </label>
                                <input type="password" name="senha" id="senha" placeholder="Digite sua senha" required>
                                <label class="check" for="senha" onclick="mostrarsenha()" id="check"> Mostrar </label>

                            </div>

                            <div class="opcoes">
                                <div>
                                    <input type="checkbox" name="lembre-se" id="lembre-se">
                                    <label for="lembre-se">Lembre-se de mim</label>
                                </div>
                                <a href='#'> Esqueceu a Senha? </a>
                            </div>

                            <?php
                            if (isset($_POST['btn-login'])) {
                                $quantidade = $sql_query->num_rows;

                                if ($quantidade == 1) {
                                    $_SESSION['id'] = $usuario['ID_usuario'];
                                    $_SESSION['nome'] = $usuario['nome'];
                                    $_SESSION['email'] = $usuario['email'];
                                    header("Location: index.php");
                                } else {
                                    echo "<span style='color: red;'> Dados Incorretos! </span> ";
                                }
                            }
                            ?>
                            <input class="btn-cadastro" name="btn-login" type="submit" value="Entrar">

                            <footer class="link-cadastro">
                                <p> Não possui cadastro? <a href="cadastro.php">Clique aqui</a>
                                </p>
                            </footer>

                        </section>
    </div>
    </form>
    </section>
    </main>


</body>
<script src="js/js.js"></script>

</html>