<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/cadastro.css">
    <link rel="stylesheet" href="css/menu.css">
    <title>CONCICLE | Cadastro</title>
</head>

<body>
    <div id="container">
        <nav>
            <ul class="a">
                <li class="logotipo">
                    <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li>
                            <a href='login.php' class='cursor'>Login</a>
                        </li>
                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <main class="bg">
            <section class="login">
                <header class="header-login">
                    <h1> Conscientize, Recicle & Receba </h1>
                    <h2> Faça parte dessa equipe e mude o mundo! </h2>
                </header>

                <form action="" method="post">
                    <main class="main-login">
                        <section class="card-login">
                            <h1> Crie seu Cadastro </h1>
                            <div class="textfield">
                                <label for="nome"> Nome*</label>
                                <input type="text" name="nome" placeholder="Nome Completo" autocomplete="off" required>
                            </div>

                            <div class="textfield">
                                <label for="sobrenome"> Sobrenome* </label>
                                <input type="text" name="sobrenome" id="sobrenome" placeholder="123.456.789-XX"
                                    maxlength="14" autocomplete="off" required>
                            </div>

                            <div class="textfield">
                                <label for="cpf"> CPF* </label>
                                <input type="text" name="cpf" id="cpf" placeholder="123.456.789-XX" maxlength="14"
                                    autocomplete="off" required>
                            </div>

                            <div class="textfield">
                                <label for="email"> E-mail* </label>
                                <input type="email" name="email" placeholder="E-mail@exemplo.com" autocomplete="off"
                                    required>
                            </div>

                            <div class="textfield">
                                <label for="senha"> Senha* </label>
                                <input type="password" name="senha" id="senha" placeholder="Digite sua senha"
                                    autocomplete="off" required>
                                <label class="check" for="exibirSenha" onclick="mostrarsenha()" id="check"
                                    style="cursor: pointer;"> Mostrar
                                </label>

                            </div>

                            <div class="textfield">
                                <label for="senha"> Repita sua senha* </label>
                                <input type="password" name="senha2" id="senha2" placeholder="Repita sua senha"
                                    autocomplete="off" required>
                                <label class="check" for="exibirSenha" onclick="mostrarsenha2()" id="check2"
                                    style="cursor: pointer;"> Mostrar
                                </label>
                            </div>


                            <?php
                            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                $senha = $_POST['senha'];
                                $rsenha = $_POST['senha2'];

                                if ($senha != $rsenha) {
                                    echo "<div class='echo'> *As senhas não coincidem! </div>";
                                } else {

                                    if (isset($_POST['btn-go'])) {

                                        function formatCpf($CPF)
                                        {
                                            $CPF_LENGTH = 14;
                                            $CPF = preg_replace("/\D/", '', $_POST['cpf']);

                                            if (strlen($CPF) === $CPF_LENGTH) {
                                                return preg_replace("/(\d{3})(\d{3})(\d{3})(\d{2})/", "\$1.\$2.\$3-\$4", $CPF);
                                            }

                                            return preg_replace("/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/", "\$1.\$2.\$3/\$4-\$5", $CPF);
                                        }

                                        include('conexao/conexao.php');
                                        $nome = $conn->real_escape_string($_POST['nome']);
                                        $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
                                        $email = $conn->real_escape_string($_POST['email']);
                                        $CPF = formatCpf($conn->real_escape_string($_POST['cpf']));
                                        $sobrenome = $conn->real_escape_string($_POST['sobrenome']);

                                        $sql_code = "SELECT * FROM usuario WHERE email = '$email'";
                                        $sql_query = $conn->query($sql_code) or die("Falha na execução do código SQL: " . $conn->error);
                                        $usuario = $sql_query->fetch_assoc();

                                        if ($usuario == '') {
                                            $sql = "INSERT INTO usuario (nome, sobrenome, senha, email, CPF) VALUES ('{$nome}','{$sobrenome}', '{$senha}', '{$email}', '{$CPF}')";
                                            $res = $conn->query($sql) or die("Falha: " . $conn->error);
                                            header("location: login.php");
                                        } else {
                                            while ($usuario = $sql_query->fetch_assoc()) {
                                                if ($usuario['email'] == $email) {
                                                    echo "<div style='color: red;'> Email ja cadastrado! </div> ";
                                                } else {
                                                    // Criptografia de senha: https://www.youtube.com/watch?v=MPHJVesOAYA&ab_channel=ZeroBugs-ProgramaçãoemTutorial
                                                    $sql = "INSERT INTO usuario (nome, sobrenome, senha, email, CPF) VALUES ('{$nome}','{$sobrenome}', '{$senha}', '{$email}', '{$CPF}')";
                                                    $res = $conn->query($sql) or die("Falha: " . $conn->error);
                                                    header("location: login.php");

                                                }
                                            }

                                        }
                                    }
                                }
                            }
                            ?>
                            <input class="btn-cadastro" name="btn-go" type="submit" value="Avançar →">

                            <footer class="link-cadastro">
                                <p> Já possui cadastro? <a href="login.php">Clique aqui</a>
                                </p>
                            </footer>

                        </section>
                    </main>
                </form>
            </section>
        </main>
    </div>
</body>
<script src="js/js.js"> </script>
<script src="js/cpf.js"> </script>

</html>