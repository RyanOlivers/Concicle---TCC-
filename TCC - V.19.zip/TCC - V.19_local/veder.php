<?php
if (isset($_POST['categ_button_mad'])) {
    $categ_prod = $_SESSION['categ_prod'];
    $nome_prod = $_SESSION['nome_prod'];
    $desc_prod = $_SESSION['comentario_prod'];
    $qtd_prod = $_SESSION['qtd_prod'];
    $valor_prod = $_SESSION['valor_prod'];
    $categ_prod = $_SESSION['categ_prod'];
    $id_usuario_prod = $_SESSION['id'];
    $sql = "INSERT INTO produto (ID_categ, ID_usuario, quantidade, preco, nome, descricao) VALUES 
                                ('{$categ_prod}','{$id_usuario_prod}', '{$qtd_prod}', '{$valor_prod}', '{$nome_prod}','{$desc_prod}')";
    $res = $conn->query($sql) or die("Falha: " . $conn->error);
    header("location: index.php");
    exit(); // Certifique-se de sair após o redirecionamento
} elseif (isset($_POST['categ_button_plas'])) {
    $_SESSION['categ_prod'] = $_POST['categ_button_plas'];
    $nome_prod = $_SESSION['nome_prod'];
    $desc_prod = $_SESSION['comentario_prod'];
    $qtd_prod = $_SESSION['qtd_prod'];
    $valor_prod = $_SESSION['valor_prod'];
    $categ_prod = $_SESSION['categ_prod'];
    $id_usuario_prod = $_SESSION['id'];
    $sql = "INSERT INTO produto (ID_categ, ID_usuario, quantidade, preco, nome, descricao) VALUES 
                                ('{$categ_prod}','{$id_usuario_prod}', '{$qtd_prod}', '{$valor_prod}', '{$nome_prod}','{$desc_prod}')";
    $res = $conn->query($sql) or die("Falha: " . $conn->error);
    header("location: vender-step-2.php");
    exit(); // Certifique-se de sair após o redirecionamento
} elseif (isset($_POST['categ_button_vidro'])) {
    $_SESSION['categ_prod'] = $_POST['categ_button_vidro'];
} elseif (isset($_POST['categ_button_met'])) {
    $_SESSION['categ_prod'] = $_POST['categ_button_met'];
} elseif (isset($_POST['categ_button_pvc'])) {
    $_SESSION['categ_prod'] = $_POST['categ_button_pvc'];
}
echo "<pre>";
print_r($_SESSION);
echo "</pre>";
?>