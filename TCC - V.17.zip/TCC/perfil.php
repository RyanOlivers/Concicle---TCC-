<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/perfil.css">

    <title>CONCICLE | Conscientize, Recicle & Receba</title>
</head>

<body>
    <div id="container">
        <nav id="menu">
            <ul class="a">
                <li class="logotipo">
                    <a href="index.html"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li class="li-pai">
                            <p class='cursor dropdown-arrow'>Login</p>
                            <ul class='sub-menus'>
                                <li class="perfil">
                                    <a href="perfil.html">
                                        <img src="img/shopping-cart.svg" alt="">
                                        <div class="sub-text">
                                            <p>Olá</p>
                                            <p>Seu Nome</p>
                                        </div>
                                    </a>
                                </li>

                                <li><a href='http://'>Products 1</a></li>
                                <li><a href='http://'>Products 2</a></li>
                                <li><a href='http://'>Products 3</a></li>
                            </ul>
                        </li>
                        <li class="sobre"><a href="Sobre.html">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <main>
            <ul>
                <li class="perfil-area">
                    <div class="dados">
                        <img src="img/user-gray.svg" alt="">
                        <div>
                            <p style="font-size: 13pt; font-weight: bold; color: #202020;">Seu Nome</p>
                            <p style="color: #777777;">Email: Phlip.soares@etec.sp.gov.br</p>
                        </div>
                    </div>
                    <img class="edit" src="img/edit.svg" alt="">
                </li>
                <li>
                    <div class="dados">
                        <img src="img/user-green.svg" alt="">
                        <div>
                            <p style="font-size: 13pt; font-weight: bold; color: #202020;">Dados da conta</p>
                            <p style="color: #777777;">E-mail, telefone, usuário...</p>
                        </div>
                    </div>
                    <img class="edit" src="img/arrow.svg" alt="">
                </li>
                <li>
                    <div class="dados">
                        <img src="img/lock.svg" alt="">
                        <div>
                            <p style="font-size: 13pt; font-weight: bold; color: #202020;">Segurança</p>
                            <p style="color: #777777;">Senha</p>
                        </div>
                    </div>
                    <img class="edit" src="img/arrow.svg" alt="">
                </li>
                <li>
                    <div class="dados">
                        <img src="img/card-green.svg" alt="">
                        <div>
                            <p style="font-size: 13pt; font-weight: bold; color: #202020;">Cartões</p>
                            <p style="color: #777777;">Cartões cadastrados na sua conta</p>
                        </div>
                    </div>
                    <img class="edit" src="img/arrow.svg" alt="">
                </li>
                <li>
                    <div class="dados">
                        <img src="img/address-marker-green.svg" alt="">
                        <div>
                            <p style="font-size: 13pt; font-weight: bold; color: #202020;">Endereço</p>
                            <p style="color: #777777;">Endereços salvos na sua conta</p>
                        </div>
                    </div>
                    <img class="edit" src="img/arrow.svg" alt="">
                </li>
                <li>
                    <div class="dados">
                        <img src="img/privacy-green.svg" alt="">
                        <div>
                            <p style="font-size: 13pt; font-weight: bold; color: #202020;">Termos de privacidade</p>
                            <p style="color: #777777;">Termos de privacidade, notificações...</p>
                        </div>
                    </div>
                    <img class="edit" src="img/arrow.svg" alt="">
                </li>
            </ul>
        </main>
        <aside class="menu-lateral">
            <div class="title">
                <img id="expandButton" src="img/hamburger.png" alt="Menu" onclick="expandMenu()">
                <p>Minha Conta</p>
            </div>
            <ul>
                <a href="">
                    <li class="seletec-topic"><img src="img/user-gray.svg" alt="perfil-icon">
                        <p>Meu Perfil</p>
                    </li>
                </a>
                <a href="favoritos.html">
                    <li class="disseletec-topic"><img src="img/heart-gray.svg" alt="favoritos-icon">
                        <p>Favoritos</p>
                    </li>
                </a>
                <a href="">
                    <li class="disseletec-topic"><img src="img/bag-gray.svg" alt="historico-icon">
                        <p>Historico/Compras</p>
                    </li>
                </a>
                <a href="">
                    <li class="disseletec-topic"><img src="img/tag-gray.svg" alt="vender-icon">
                        <p>Vender</p>
                    </li>
                </a>
            </ul>
        </aside>

        <footer class="rodape">
            <div class="rodape-superior">
                <div class="ajuda">
                    <p class="title">AJUDA</p>
                    <ul>
                        <li><a href="">Chat online</a></li>
                        <li><a href="">Fale conosco</a></li>
                        <li><a href="">Dúvidas frequentes</a></li>
                        <li><a href="">Politica de trocas</a></li>
                    </ul>
                </div>

                <div class="las">
                    <div class="acompanhe-nos">
                        <p class="title">acompanhe-nos</p>
                        <ul>
                            <li><a href=""><img src="img/baseline-whatsapp.svg" alt="whatsapp-icon"></a></li>
                            <li><a href=""><img src="img/facebook-outlined.svg" alt="facebook-icon"></a></li>
                            <li><a href=""><img src="img/instagram.svg" alt="instagram-icon"></a></li>
                            <li><a href=""><img src="img/twitter.svg" alt="twitter-icon"></a></li>
                        </ul>
                    </div>
                    <div class="email">
                        <p class="title">Receba novas promoções</p>
                        <p>Cadastre-se e seja o primeiro a receber novidades!</p>
                        <input type="email" name="email" class="email-input"><input type="submit" value="OK"
                            class="email-btn">
                    </div>
                    <div class="metodos-pagamento-superior">
                        <p class="title">Metodos de pagemento</p>
                        <ul>
                            <li><img src="img/pix.svg" alt="pix-icon"></li>
                            <li><img src="img/mercadopago.svg" alt="mercadopago-icon"></li>
                            <li><img src="img/mastercard.svg" alt="mastercard-icon"></li>
                            <li><img src="img/elo.svg" alt="elo-icon"></li>
                            <li><img src="img/visa-fill.svg" alt="visa-icon"></li>
                        </ul>
                    </div>
                </div>
                <div class="institucional">
                    <p class="title">institucional</p>
                    <ul>
                        <li><a href="">chat online</a></li>
                        <li><a href="">fale conosco</a></li>
                        <li><a href="">dúvidas frequentes</a></li>
                        <li><a href="">Politica de trocas</a></li>
                    </ul>
                </div>
                <div class="seguranca">
                    <p class="title">REDES SOCIAIS</p>
                    <ul>
                        <img src="img/instagram.png" alt="INSTA-icon">
                        <img src="img/youtube.png" alt="youtube-icon">
                        <img src="img/facebook.png" alt="facebook-icon">
                    </ul>
                </div>

            </div>
            <hr>
            <br>
            <div class="rodape-inferior">

                <div class="local">
                    <p>CNPJ: 18.189.510/0001-14</p>
                    <p>Travessa Marataízes, 94, Vista da Serra I, Serra, ES - CEP: 29176-330</p>
                </div>
                <div class="metodos-pagamento-inferior">
                    <p class="title">Metodos de pagamento</p>
                    <ul>
                        <li><img src="img/pix.svg" alt="pix-icon"></li>
                        <li><img src="img/mercadopago-white.svg" alt="mercadopago-icon"></li>
                        <li><img src="img/mastercard.svg" alt="mastercard-icon"></li>
                        <li><img src="img/elo.svg" alt="elo-icon"></li>
                        <li><img src="img/visa-fill-white.svg" alt="visa-icon"></li>
                    </ul>
                </div>
            </div>
        </footer>
    </div>
    <script src="js/js.js"></script>
</body>

</html>