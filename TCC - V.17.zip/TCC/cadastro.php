<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/cadastro.css">
    
    <title>CONCICLE | Cadastro</title>
</head>
<body>
    <div id="container">
        <nav id="menu">
            <div class="a">
                <div class="logotipo">
                    <a href="index.html"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </div>
                <div class="usuario">
                    <ul>
                        <li>
                            <p class='cursor dropdown-arrow'>Login</p>
                        </li> 
                        <li class=""><a href="Sobre.html">Sobre</a></li>
                    </ul>
                </div>  
            </div>
            
        </nav>
    </div> 
    <div class="main-login">
        <div class="left-login">
            <h1>  Conscientize, Recicle & Receba </h1>
            <img src="img/recycling-animate.svg" class="left-login-image" alt="animate-recicle">
            <h2>\ Faça parte dessa equipe e mude o mundo! </h2>
        </div>
        
        <div class="right-login">
            <form class="card-login" action="php/cadastro.php method="post">
                <h1> Crie seu Cadastro</h1>
                <div class="textfield">
                    <label for="nome"> Nome e Sobrenome</label>
                    <input type="text" name="nome" placeholder="Nome Completo">
                </div>

                <div class="textfield">
                    <label for="usuario"> Usuário</label>
                    <input type="text" name="usuario" placeholder="Usuário">
                </div>

                <div class="textfield">
                    <label for="email"> E-mail </label>
                    <input type="email" name="email" placeholder="E-mail@exemplo.com">
                </div>

                <div class="textfield">
                    <label for="senha"> Senha</label>
                    <input type="password" name="senha" placeholder="Digite sua senha">
                </div>

                <div class="textfield">
                    <label for="senha"> Repita sua senha</label>
                    <input type="password" name="senha2" placeholder="Repita sua senha">
                </div>
                <input type="submit" value="Avançar →" class="btn-cadastro">
                <div class="link-cadastro">
                <p class="p"> Já possui cadastro? <a href="login.html"> <b class="b"> Clique aqui</b></a> </p>
                </div>
            </form>
        </div>
 
    </div>
</body>
<script src="js/js.js"></script>
</html>