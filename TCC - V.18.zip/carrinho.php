<!DOCTYPE html>
<html>
<head>
    <title>Carrinho de Compras</title>
    <link rel="stylesheet" type="text/css" href="css/carrinho.css">
</head>
<body>

    <div id="boxCarrinho">
        <h2 class="titulo-carrinho"> Meu Carrinho </h2>
        <div id="carrinho"></div>
        <div id="subtotalCompra">Subtotal:</div>
        <div class="finalizar-compra-container">
            <button id="finalizarBtn">Finalizar Compra</button>
        </div>
    </div>

    <button id="adicionarBtn" onclick="adicionarProduto()">Adicionar Produto</button>

    <script src="js/carrinho.js"></script>
</body>
</html>
