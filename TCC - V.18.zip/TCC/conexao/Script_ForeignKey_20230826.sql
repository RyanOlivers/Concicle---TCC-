ALTER TABLE user_ender
ADD CONSTRAINT FK_IDusuario_ender
FOREIGN KEY (ID_usuario) REFERENCES usuario(ID_usuario);

ALTER TABLE user_ender
ADD CONSTRAINT FK_IDendereco_user
FOREIGN KEY (ID_endereco) REFERENCES endereco(ID_endereco);

ALTER TABLE contato
ADD CONSTRAINT FK_IDusuario_contato
FOREIGN KEY (ID_usuario) REFERENCES usuario(ID_usuario);

ALTER TABLE pedido
ADD CONSTRAINT FK_ID_UserEnder_pedido
FOREIGN KEY (ID_userEnder) REFERENCES user_ender(ID_userEnder);

ALTER TABLE pedido_prod
ADD CONSTRAINT FK_IDpedido_produto
FOREIGN KEY (ID_pedido) REFERENCES pedido(ID_pedido);

ALTER TABLE pedido_prod
ADD CONSTRAINT FK_IDproduto_pedido
FOREIGN KEY (ID_prod) REFERENCES produto(ID_prod);

ALTER TABLE produto
ADD CONSTRAINT FK_IDcateg_prod
FOREIGN KEY (ID_categ) REFERENCES categoria(ID_categ);

ALTER TABLE recibo
ADD CONSTRAINT FK_IDpedido_recibo
FOREIGN KEY (ID_pedido) REFERENCES pedido(ID_pedido);

ALTER TABLE avaliacao
ADD CONSTRAINT FK_IDusuario_avaliacao
FOREIGN KEY (ID_usuario) REFERENCES usuario(ID_usuario);

ALTER TABLE avaliacao
ADD CONSTRAINT FK_IDproduto_avaliacao
FOREIGN KEY (ID_prod) REFERENCES produto(ID_prod);

ALTER TABLE imagens
ADD CONSTRAINT FK_IDproduto
FOREIGN KEY (ID_prod) REFERENCES produto(ID_prod);

ALTER TABLE anunciar
ADD CONSTRAINT FK_IDproduto_anunciar
FOREIGN KEY (ID_prod) REFERENCES produto(ID_prod);

ALTER TABLE anunciar
ADD CONSTRAINT FK_IDusuario_anunciar
FOREIGN KEY (ID_usuario) REFERENCES usuario(ID_usuario);



