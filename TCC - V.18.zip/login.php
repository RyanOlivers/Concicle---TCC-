<?php
 if(!isset($_SESSION)) {
    session_start();
}

include('conexao/conexao.php');

if(isset($_POST['email']) || isset($_POST['senha'])) {

        $email = $conn->real_escape_string($_POST['email']);
        $senha = $_POST['senha'];

        if(password_verify($senha, $_SESSION['senha'])){
            $senha = $_SESSION['senha'];
        }
      
        $sql_code = "SELECT * FROM usuario WHERE email = '$email' AND senha = '$senha'";
        $sql_query = $conn->query($sql_code) or die("Falha na execução do código SQL: " . $conn->error);

        }

?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/login.css">
    
    <title> CONCICLE | Login</title>
</head>

<body>
    <div id="container">
        <nav id="menu">
            <div class="logotipo">
                <a href="main.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
            </div>
            <div class="usuario">
                <ul>
                    <li class="button-select"><a href="login.php">Login</a></li>
                    <li><a href="Sobre.php"> Sobre </a></li>
                </ul>
            </div>
            <!--
            <div class="usos">
                <ul>
                    <li class="button-select">
                        <a href=""><img src="img/home-outline.svg" alt="" srcset=""></a>
                    </li>
                    
                    <li class="search-bar">
                        <input type="text" name="pesquisa" id="pesquisa" placeholder="Pesquisar">
                    </li>
                    <li>
                        <a href="">
                            <img src="img/shopping-cart.svg" alt="carrinho">    
                        </a>
                    </li>
                </ul>
            </div>
            -->
        </nav>
    </div>
    <div class="main-login">
        <div class="left-login">
            <h1> Conscientize, Recicle & Receba </h1>
            <img src="img/recycling-animate.svg" class="left-login-image" alt="animate-recicle">
            <h2> Faça parte dessa equipe e mude o mundo! </h2>

        </div>

    <form action="" method="post">
        <div class="right-login">
            <div class="card-login">
                <h1> Entre na sua conta </h1>

                <div class="textfield">
                    <label for="email"> E-mail </label>
                    <input type="email" name="email" placeholder="E-mail@exemplo.com">
                </div>

                <div class="textfield">
                    <label for="senha"> Senha* </label>
                    <input type="password" name="senha" id="senha" placeholder="Digite sua senha" required>
                    <label class="check" for="exibirSenha" onclick="mostrarsenha()" id="check"> Mostrar </label>


                    
                    
                </div>
                
                <div class="opcoes">
                    <div>
                        <input type="checkbox" name="lembre-se" id="lembre-se">
                        <label for="lembre-se">Lembre-se de mim</label>
                    </div>
                            

                    <p> Esqueceu a Senha? </p>
                </div>

                         <?php
                            if(isset($_POST['btn-login'])){
                                $quantidade = $sql_query->num_rows;

                                if($quantidade == 1) {
                                    $usuario = $sql_query->fetch_assoc();
                                        $_SESSION['id'] = $usuario['id'];
                                        $_SESSION['nome'] = $usuario['nome_completo'];
                                        header("Location: main.php");
                                    } else {
                                        echo "<div class='dados'> Dados Incorretos! </div> ";
                                    }
                            }
                        ?>
                <input class="btn-cadastro" name="btn-login" type="submit" value="Entrar">  
                <div class="link-cadastro">
                    <p class="p"> Não possui cadastro? <a href="cadastro.php"> <b class="b"> Clique aqui</b></a> </p>
                </div>
    </form>
            </div>
        </div>

    </div>

</body>
<script src="js/js.js"></script>

</html>