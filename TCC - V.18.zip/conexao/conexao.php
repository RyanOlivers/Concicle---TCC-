<style>

        .echo {
            color: #FF0000;
            font-size: 10pt;
            display: flex;
            align-items: center;
        }

        .dados {
            color: #FF0000;
            margin: 20px 0 0px;
            font-size: 10.5pt;
            display: flex;
            flex-direction: column;
        }

    </style>

<?php
$local = 'localhost';
$user = 'root';
$pass = '';
$db_name = 'tcc_concicle';

$conn = mysqli_connect($local, $user, $pass, $db_name, 3312);

if ($conn->error) {
    die("Conexão Mal-sucedida!" . $conn->error);
}
//   else {
//      echo "Conexão Bem-sucedida!";
//  }

?>