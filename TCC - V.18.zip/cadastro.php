<?php
if (!isset($_SESSION)) {
    session_start();
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/cadastro.css"> 

    <title>CONCICLE | Cadastro</title>
</head>
<body>
    <div id="container">
        <nav id="menu">
            <div class="logotipo">
                <a href="main.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
            </div>
            <div class="usuario">
                <ul>
                    <li class="button-select"><a href=""> Login </a></li>
                    <li><a href="Sobre.php">Sobre</a></li>
                </ul>
            </div>
            <!--
            <div class="usos">
                <ul>
                    <li class="button-select">
                        <a href=""><img src="img/home-outline.svg" alt="" srcset=""></a>
                    </li>
                    
                    <li class="search-bar">
                        <input type="text" name="pesquisa" id="pesquisa" placeholder="Pesquisar">
                    </li>
                    <li>
                        <a href="">
                            <img src="img/shopping-cart.svg" alt="carrinho">    
                        </a>
                    </li>
                </ul>
            </div>-->
        </nav>
    </div> 
    <div class="main-login">
        <div class="left-login">
            <h1>  Conscientize, Recicle & Receba </h1>
            <img src="img/recycling-animate.svg" class="left-login-image" alt="animate-recicle">
            <h2> Faça parte dessa equipe e mude o mundo! </h2>
        </div>

    <form action="" method="post">
        <div class="right-login">
            <div class="card-login">
                <h1> Crie seu Cadastro </h1>
                <div class="textfield">
                    <label for="nome"> Nome e Sobrenome*</label>
                    <input type="text" name="nome" placeholder="Nome Completo" autocomplete="off"  required>
                </div>

                <div class="textfield">
                    <label for="usuario"> CPF* </label>
                    <input type="text" name="cpf" id="cpf" placeholder="123.456.789-XX" maxlength="14" autocomplete="off" required>
                </div>

                <div class="textfield">
                    <label for="email"> E-mail* </label>
                    <input type="email" name="email" placeholder="E-mail@exemplo.com" autocomplete="off" required>
                </div>

                <div class="textfield">
                    <label for="senha"> Senha* </label>
                    <input type="password" name="senha" id="senha" placeholder="Digite sua senha" autocomplete="off" required >
                    <label class="check" for="exibirSenha" onclick="mostrarsenha()" id="check"> Mostrar </label>
                    
                </div>

                <div class="textfield">
                    <label for="senha"> Repita sua senha* </label>
                    <input type="password" name="senha2" id="senha2"placeholder="Repita sua senha" autocomplete="off" required>
                    <label class="check" for="exibirSenha" onclick="mostrarsenha2()" id="check2"> Mostrar </label>

                </div>
                

                <?php
                    if($_SERVER['REQUEST_METHOD'] === 'POST'){
                        $senha = $_POST['senha'];
                        $rsenha = $_POST['senha2'];

                        if($senha != $rsenha) {
                            echo "<div class='echo'> *As senhas não coincidem! </div>";
                            
                        } else {
                            
                            if(isset($_POST['btn-go'])){

                                    function formatCpf($CPF)
                                    {
                                    $CPF_LENGTH = 14;
                                    $CPF = preg_replace("/\D/", '', $_POST['cpf']);
                                    
                                    if (strlen($CPF) === $CPF_LENGTH) {
                                        return preg_replace("/(\d{3})(\d{3})(\d{3})(\d{2})/", "\$1.\$2.\$3-\$4", $CPF);
                                    } 
                                    
                                    return preg_replace("/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/", "\$1.\$2.\$3/\$4-\$5", $CPF);
                                    }

                                include('conexao/conexao.php');
                                $nome = $conn->real_escape_string($_POST['nome']);
                                $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
                                $email = $conn->real_escape_string($_POST['email']);
                                $CPF = formatCpf($conn->real_escape_string($_POST['cpf']));
                                $_SESSION['senha'] = $senha;

                                // Criptografia de senha: https://www.youtube.com/watch?v=MPHJVesOAYA&ab_channel=ZeroBugs-ProgramaçãoemTutorial

                                $sql = "INSERT INTO usuario (nome_completo, senha, email, CPF) VALUES ('{$nome}', '{$senha}', '{$email}', '{$CPF}')";
                                $res = $conn->query($sql) or die("Falha: " . $conn->error);
                                header("Location: login.php");
                                }
                            } 
                    }  

                    
                    ?>
                <input class="btn-cadastro" name="btn-go" type="submit" value="Avançar →" >  

                <div class="link-cadastro">
                <p class="p"> Já possui cadastro? <a href="login.php"> <b class="b"> Clique aqui</b></a> </p>

                </div>
            </div>
        </div>
    </form>
    </div>   
    
    
   
    
</body>
<script src="js/js.js"> </script>
<script src="js/cpf.js"> </script>
</html>