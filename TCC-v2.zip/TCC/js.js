var menu = document.getElementById("menu");

window.addEventListener("scroll", function() {
  if (window.pageYOffset > (window.innerHeight * 0.92)) { /* 10vh corresponde a 10% da altura da janela de visualização */
    menu.classList.add("dark");
  } else {
    menu.classList.remove("dark");
  }
});