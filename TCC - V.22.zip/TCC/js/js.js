
var menu = document.getElementById("menu");

window.addEventListener("scroll", function () {
  if (window.pageYOffset > (window.innerHeight * 0.1)) {
    menu.classList.add("hide-menu");
  } else {
    menu.classList.remove("hide-menu");
  }
});

// Verificar a posição inicial da janela e ocultar o menu, se necessário
if (window.pageYOffset > (window.innerHeight * 0.01)) {
  menu.classList.add("hide-menu");
}

menu.addEventListener("mouseenter", function () {
  menu.classList.remove("hide-menu");
});

menu.addEventListener("mouseleave", function () {
  if (window.pageYOffset > (window.innerHeight * 0.01)) {
    menu.classList.add("hide-menu");
  }
});
window.addEventListener("scroll", function () {
  if (window.pageYOffset > (window.innerHeight * 0.01)) { /* 10vh corresponde a 10% da altura da janela de visualização */
    menu.classList.add("dark");
  } else {
    menu.classList.remove("dark");
  }
});

var stars = document.querySelectorAll('.star-icon');

document.addEventListener('DOMContentLoaded', function () {
  var stars = document.querySelectorAll('.star-icon');

  stars.forEach(function (star) {
    star.addEventListener('click', function () {
      stars.forEach(function (sibling) {
        sibling.classList.remove('ativo');
      });
      this.classList.add('ativo');
      console.log(this.getAttribute('data-avaliacao'));
    });
  });
});

// Obtém os elementos checkboxes e a div



function myFunction1() {
  var url = document.getElementById("img1").value;
  console.log(url);
  document.getElementById("minhaImagem").style.backgroundImage = `url('${url}')`;
  document.getElementById("minhaImagem").style.backgroundRepeat = "no-repeat";
  document.getElementById("minhaImagem").style.backgroundSize = "84%";
  document.getElementById("minhaImagem").style.backgroundPosition = "center";
  document.querySelector(".itens-1").style.backgroundColor = "rgba(255, 255, 255, 0.534)";
  document.querySelector(".itens-2").style.backgroundColor = "";
  document.querySelector(".itens-3").style.backgroundColor = "";
  document.querySelector(".itens-4").style.backgroundColor = "";
}
function myFunction2() {
  document.getElementById("minhaImagem").style.backgroundImage = "url('img/red-bin.png')";
  document.getElementById("minhaImagem").style.backgroundRepeat = "no-repeat";
  document.getElementById("minhaImagem").style.backgroundSize = "100%";
  document.getElementById("minhaImagem").style.backgroundPosition = "center";
  document.querySelector(".itens-2").style.backgroundColor = "rgba(255, 255, 255, 0.534)";
  document.querySelector(".itens-1").style.backgroundColor = "";
  document.querySelector(".itens-3").style.backgroundColor = "";
  document.querySelector(".itens-4").style.backgroundColor = "";
}
function myFunction3() {
  document.getElementById("minhaImagem").style.backgroundImage = "url('img/green-bin.png')";
  document.getElementById("minhaImagem").style.backgroundRepeat = "no-repeat";
  document.getElementById("minhaImagem").style.backgroundSize = "80%";
  document.getElementById("minhaImagem").style.backgroundPosition = "center";
  document.querySelector(".itens-3").style.backgroundColor = "rgba(255, 255, 255, 0.534)";
  document.querySelector(".itens-2").style.backgroundColor = "";
  document.querySelector(".itens-1").style.backgroundColor = "";
  document.querySelector(".itens-4").style.backgroundColor = "";
}
function myFunction4() {
  document.getElementById("minhaImagem").style.backgroundImage = "url('img/yellow-bin.png')";
  document.getElementById("minhaImagem").style.backgroundRepeat = "no-repeat";
  document.getElementById("minhaImagem").style.backgroundSize = "80%";
  document.getElementById("minhaImagem").style.backgroundPosition = "center";
  document.querySelector(".itens-4").style.backgroundColor = "rgba(255, 255, 255, 0.534)";
  document.querySelector(".itens-2").style.backgroundColor = "";
  document.querySelector(".itens-3").style.backgroundColor = "";
  document.querySelector(".itens-1").style.backgroundColor = "";
}

let count = 1;
document.getElementById("radio1").checked = true;

setInterval(function () {
  nextImage();
}, 8000);

function nextImage() {
  count++;
  if (count > 4) {
    count = 1;
  }
  document.getElementById("radio" + count).checked = true;
}
const sidebar = document.querySelector('.menu-lateral');
const footer = document.querySelector('.rodape');

function atualizarPosicaoMenu() {
  const alturaMenu = sidebar.offsetHeight;
  const topoRodape = footer.getBoundingClientRect().top;

  if (topoRodape < alturaMenu) {
    const sobreposicao = alturaMenu - topoRodape;
    sidebar.style.transform = `translateY(-${sobreposicao}px)`;
  } else {
    sidebar.style.transform = 'none';
  }
}

// Chamada inicial para atualizarPosicaoMenu para definir a posição inicial correta
atualizarPosicaoMenu();

// Chame atualizarPosicaoMenu quando a janela for rolada
window.addEventListener('scroll', atualizarPosicaoMenu);

document.addEventListener("DOMContentLoaded", () => {
  const openCartButton = document.querySelector(".open-cart-button");
  const closeCartButton = document.querySelector(".close-cart-button");
  const cartSidebar = document.querySelector(".cart-sidebar");

  openCartButton.addEventListener("click", () => {
    cartSidebar.classList.add("open");
  });

  closeCartButton.addEventListener("click", () => {
    cartSidebar.classList.remove("open");
  });
});

function clickMenu() {
  var paragraphs = document.querySelectorAll('.menu-lateral p');
  
  for (var i = 0; i < paragraphs.length; i++) {
    if (paragraphs[i].style.display == "block") {
      paragraphs[i].style.display = "none";
    }else{
      paragraphs[i].style.display = "block";
    }
  }
}








