<?php
include('conexao/conexao.php');


?>

<!DOCTYPE html>

<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/cadastro.css">
    <link rel="stylesheet" href="css/menu.css">
    <title>CONCICLE | Cadastro</title>
</head>

<body>
    <div id="container">
        <nav>
            <ul class="a">
                <li class="logotipo">
                    <a href="ecommerce.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li>
                            <a href='login.php' class='cursor'>Login</a>
                        </li>
                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <main class="bg">
            <section class="login">
                <header class="header-login">
                    <h1> Conscientize, Recicle & Receba </h1>
                    <h2> Faça parte dessa equipe e mude o mundo! </h2>
                </header>

                <form action="" method="post">
                    <main class="main-login">
                        <section class="card-login">
                            <h1> Crie seu Cadastro </h1>
                            <div class="textfield">
                                <label for="nome"> Nome*</label>
                                <input type="text" name="nome" placeholder="Digite aqui..." autocomplete="off" required
                                    maxlength="15">
                            </div>

                            <div class="textfield">
                                <label for="sobrenome"> Sobrenome* </label>
                                <input type="text" name="sobrenome" id="sobrenome" placeholder="Digite aqui..."
                                    maxlength="30" autocomplete="off" required>
                            </div>

                            

                            <div class="textfield">
                                <label for="email"> E-mail* </label>
                                <input type="email" name="email" placeholder="E-mail@exemplo.com" autocomplete="off"
                                    required>
                            </div>
                            <div class="textfield">
                                <label for="usuario_cargo"> usuario </label>
                                <input type="radio" name="usuario_cargo" id="usuario_cargo" value='1'>
                                <label for="vendedor_cargo"> vendedor </label>
                                <input type="radio" name="usuario_cargo" id="vendedor_cargo" value='2'>
                                <!-- <input type="email" name="email" placeholder="E-mail@exemplo.com" autocomplete="off"required> -->
                            </div>

                            <div class="textfield">
                                <label for="senha"> Senha* </label>
                                <input type="password" name="senha" id="senha" placeholder="Digite sua senha"
                                    autocomplete="off" required>
                                <label class="check" for="exibirSenha" onclick="mostrarsenha()" id="check"
                                    style="cursor: pointer;"> Mostrar
                                </label>

                            </div>

                            <div class="textfield">
                                <label for="senha2"> Repita sua senha* </label>
                                <input type="password" name="senha2" id="senha2" placeholder="Repita sua senha"
                                    autocomplete="off" required>
                                <label class="check" for="exibirSenha" onclick="mostrarsenha2()" id="check2"
                                    style="cursor: pointer;"> Mostrar
                                </label>
                            </div>
                            <input class="btn-cadastro" name="btn-go" type="submit" value="Avançar →">

                            <?php
                            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                                $senha = $_POST['senha'];
                                $rsenha = $_POST['senha2'];
                                $cpf = $_POST['cpf'];
                                $cpf_val = preg_replace('/[^0-9]/is', '', $cpf);

                                if ($senha != $rsenha) {
                                    echo "<div class='echo'> *As senhas não coincidem! </div>";
                                } else {

                                    if (isset($_POST['btn-go'])) {

                                        // Verifique se o CPF tem 11 caracteres (sem considerar espaços em branco)
                                        if (strlen($cpf_val) != 11) {
                                            echo "O CPF deve conter 11 dígitos. Tente novamente.\n";
                                        } else {
                                            // Divida o CPF em caracteres individuais e armazene em variáveis separadas
                                            list($n1, $n2, $n3, $n4, $n5, $n6, $n7, $n8, $n9, $n10, $n11, $n12, $n13, $n14) = str_split($cpf);

                                            $soma1 = $n1 * 10 + $n2 * 9 + $n3 * 8 + $n5 * 7 + $n6 * 6 + $n7 * 5 + $n9 * 4 + $n10 * 3 + $n11 * 2;
                                            $valid1 = $soma1 * 10 % 11;
                                            $soma2 = $n1 * 11 + $n2 * 10 + $n3 * 9 + $n5 * 8 + $n6 * 7 + $n7 * 6 + $n9 * 5 + $n10 * 4 + $n11 * 3 + $n13 * 2;
                                            $valid2 = $soma2 * 10 % 11;


                                            if (preg_match('/(\d)\1{10}/', $cpf_val)) {
                                                echo "<div style='color:red'>  *Digite um CPF válido! </div>";
                                            } elseif ($n13 == $valid1 and $n14 == $valid2) {
                                                $nome = $conn->real_escape_string($_POST['nome']);
                                                $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
                                                $email = $conn->real_escape_string($_POST['email']);
                                                $sobrenome = $conn->real_escape_string($_POST['sobrenome']);

                                                $sql_code = "SELECT * FROM usuario WHERE email = '$email' OR cpf = '$cpf_val'";
                                                $sql_query = $conn->query($sql_code) or die("Falha na execução do código SQL: " . $conn->error);
                                                $usuario = $sql_query->fetch_assoc();

                                                if ($usuario['email']) {
                                                    echo "<div style='color: red'> *Email já cadastrado! </div>";
                                                } elseif ($usuario['cpf']) {
                                                    echo "<div style='color: red'> *CPF já cadastrado! </div>";
                                                } else {
                                                    $sql = "INSERT INTO usuario (nome, sobrenome, senha, email, CPF) VALUES ('{$nome}','{$sobrenome}', '{$senha}', '{$email}', '{$cpf_val}')";
                                                    $res = $conn->query($sql) or die("Falha: " . $conn->error);
                                                    header("location: login.php");
                                                }
                                            } else {
                                                echo "<div style='color:red'>  *Digite um CPF válido! </div>";
                                            }
                                        }


                                    }
                                }
                            }
                            ?>

                            <footer class="link-cadastro">
                                <p> Já possui cadastro? </p>
                                <p> <a href="login.php">Clique aqui para logar</a> </p>
                            </footer>

                        </section>
                    </main>
                </form>
            </section>
        </main>
    </div>
</body>
<script src="js/js.js"> </script>
<script src="js/cpf.js"> </script>

</html>