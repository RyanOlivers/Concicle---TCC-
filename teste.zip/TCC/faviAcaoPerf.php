<?php
include('conexao/conexao.php');
//1 cheio, 2 vazio
if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
    $id_usuario = $_SESSION['id'];
    if ($_SERVER['REQUEST_METHOD'] === 'GET') {
        $idVal = $_GET['idN'];
        $idProd = $_GET['idP'];
        $favo = $conn->query("SELECT * from favoritar where ID_prod = $idProd");
        $resultFavo = $favo->fetch_assoc();
        //Pegando dados do fav_user
        $fav_user = $conn->query("SELECT * from fav_user where ID_user = $id_usuario");
        $resultFav_user = $fav_user->fetch_assoc();
        $idDelete = $resultFav_user['ID_fav_user'];
      if ($idVal == 1) {
            //deixa vazio
            //Deletar o cheio 
            if ($fav_user->num_rows > 0) {
                $favRel = "DELETE  FROM fav_user WHERE ID_fav_user = $idDelete ";
                $resRel = $conn->query($favRel) or die("Falha: " . $conn->error);
                $uptade = $conn->query("UPDATE favoritar SET fav_valor = 2 WHERE ID_prod = $idProd ");
                header('location: favoritos.php');
            }
        }
    }
} 