<?php
include_once("conexao/conexao.php");
if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
    $id_prod = $_GET['id_prod'];
    $id_user = $_GET['id_user'];

    $selecionarProdsCarrinho = $conn->query("SELECT * FROM carrinho_prod WHERE ID_usuario = $id_user and ID_prod = $id_prod");
    $selectCarrinho = $conn->query("SELECT produto.* FROM produto JOIN carrinho_prod ON produto.ID_prod = carrinho_prod.ID_prod WHERE carrinho_prod.ID_usuario = $id_user;");

    // $selectCarrinhoImg = $conn->query("SELECT imagens_prod.* FROM imagens_prod JOIN carrinho_prod ON imagens_prod.ID_prod = carrinho_prod.ID_prod WHERE carrinho_prod.ID_usuario = $id_user;");
    $img = $conn->query("SELECT * from imagens_prod WHERE ID_prod = $id_prod");
    ?>

    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
        <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
        <link rel="stylesheet" href="css/revisar.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/menu.css">

        <title>CONCICLE | Conscientize, Recicle & Receba</title>
    </head>

    <body>
        <div id="container">
            <nav>
                <ul class="a">
                    <li class="logotipo">
                        <a href="ecommerce.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                    </li>
                    <li class="usuario">
                        <ul>
                            <li class="li-pai">
                                <?php
                                if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
                                    echo "<p class='cursor dropdown-arrow'>" . $_SESSION['nome'] . "</p>";
                                    ?>
                                    <ul class='sub-menus'>
                                        <li class="perfil">
                                            <a href="perfil.php">
                                                <?php
                                                $id_usuario = $_SESSION['id'];
                                                $sql = $conn->query("SELECT * FROM imagens WHERE ID_user = '$id_usuario'")->fetch_assoc();
                                                echo "<img src='{$sql['caminho_imagem']}' alt=''>";
                                                ?>

                                                <div class="sub-text">
                                                    <p class="p-ola"> Olá </p>
                                                    <p class="p-name">
                                                        <?= $_SESSION['nome'] ?>
                                                    </p>
                                                </div>
                                            </a>
                                        </li>

                                        <li class="perfil-bloco"> <a href='perfil.php'> <img src="img/perfil.svg" alt=""
                                                    srcset=""> Meu perfil </a>
                                            <a href='favoritos.php'> <img src="img/favorite.svg" alt="" srcset=""> Favoritos
                                            </a>
                                            <a href=''> <img src="img/history.svg" alt="" srcset=""> Histórico/Compras
                                            </a>
                                        </li>
                                        <li class="vender-bloco"><a href='vender.php'> <img src="img/sell.svg" alt="" srcset="">
                                                Vender</a></li>
                                        <li class="ajuda-bloco"><a href='http://'> <img src="img/question.svg" alt="" srcset="">
                                                Perguntas</a></li>
                                        <li class="sair-button"><a href='logout.php'> <img src="img/logout-gray.svg" alt=""
                                                    srcset=""> sair </a></li>
                                    </ul>

                                    <?php
                                } else {
                                    echo "<a href='login.php' class='cursor'>Entrar/Cadastrar</a>";
                                }
                                ?>
                            </li>
                            <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>

            <main class='tudo'>
                <main class="">
                    <section class="produtos">
                        <h1>revise e confirme</h1>
                        <?php
                        while ($x = $selectCarrinho->fetch_assoc()) {
                            $img = $conn->query("SELECT * from imagens_prod WHERE ID_prod = $id_prod")->fetch_assoc();
                            ?>
                            <img src="<?= $img['caminho_imagem'] ?>" alt="">
                            <?php
                            $x['nome'];
                        }
                        ?>
                    </section>
                    <section></section>
                </main>
            </main>
        </div>
    </body>

    </html>
    <?php
}
?>