<?php
include_once("conexao/conexao.php");
//se estiver logado pode usar a pagina
if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
    //pega o id do produto que está na url (GET)
    $id = $_GET["id"];
    //todas as seleções no banco que preciso para colocar no front-end
    $selecionar = $conn->query("SELECT * FROM produto WHERE ID_prod = $id")->fetch_assoc();
    $selecionarImg = $conn->query("SELECT * FROM imagens_prod WHERE ID_prod = $id")->fetch_assoc();
    $selecionarImgs = $conn->query("SELECT * FROM imagens_prod WHERE ID_prod = $id");
    //codigo para desativar ou ativar a visibilidade do produto
    if (isset($_POST['ativar'])) {
        $update = $conn->query("UPDATE produto SET ativo = 1 WHERE ID_prod = $id");
        header("location: editar-produto.php?id=$id");
    } elseif (isset($_POST['desativar'])) {
        $update = $conn->query("UPDATE produto SET ativo = 0 WHERE ID_prod = $id");
        header("location: editar-produto.php?id=$id");
    }
    //codigo para deletar o produto do site e do banco
    if (isset($_POST['excluir'])) {
        $delete = $conn->query("DELETE FROM imagens_prod WHERE ID_prod = $id");
        while ($r = $selecionarImgs->fetch_assoc()) {
            $caminhos = $r['caminho_imagem'];
            if (file_exists($caminhos)) {
                if (unlink($caminhos)) {
                    $caminhoEscapado = $conn->real_escape_string($caminhos);
                    $deleteImgs = $conn->query("DELETE FROM imagens_prod WHERE caminho_imagem = '$caminhoEscapado'");
                }
            }
        }
        $true = 1;
        if ($true) {
            $delete = $conn->query("DELETE FROM produto WHERE ID_prod = $id");
            echo '<script>alert("deletado");window.location = "vender.php";</script>';
        }
    }
    //codigo para salvar as alterações que o usuario fez no produto
    if (isset($_POST['salvar'])) {
        $nome = $_POST['nome_prod'];
        $preco = $_POST['preco'];
        $quantidade = $_POST['quantidade'];
        $descricao = $_POST['descricao'];
        $categ = $_POST['categ'];
        $update_user = $conn->query("UPDATE produto SET ID_categ = $categ, quantidade = $quantidade, preco = $preco, nome = '$nome', descricao = '$descricao' WHERE ID_prod = $id");
        header("location: editar-produto.php?id=$id");
    }
    ?>
    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
        <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
        <link rel="stylesheet" href="css/editar-produto.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/menu.css">

        <title>CONCICLE | Conscientize, Recicle & Receba</title>
    </head>

    <body>
        <div id="container">
            <!--menu-->
            <nav>
                <ul class="a">
                    <li class="logotipo">
                        <a href="ecommerce.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                    </li>
                    <li class="usuario">
                        <ul>
                            <li class="li-pai">
                                <?php
                                //caso ele logado no menu mostrar o perfil dele
                                if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
                                    echo "<p class='cursor dropdown-arrow'>" . $_SESSION['nome'] . "</p>";
                                    ?>

                                    <ul class='sub-menus'>
                                        <li class="perfil">
                                            <a href="perfil.php">
                                                <?php
                                                $id_usuario = $_SESSION['id'];
                                                $sql = $conn->query("SELECT ID_img, nome_imagem, tamanho_imagem, tipo_imagem, caminho_imagem FROM imagens WHERE ID_user = '$id_usuario'")->fetch_assoc();
                                                echo "<img src='{$sql['caminho_imagem']}' alt=''>";

                                                ?>
                                                <div class="sub-text">
                                                    <p class="p-ola"> Olá </p>
                                                    <p class="p-name">
                                                        <?= $_SESSION['nome'] ?>
                                                    </p>
                                                </div>
                                            </a>
                                        </li>

                                        <li class="perfil-bloco"> <a href='perfil.php'> <img src="img/perfil.svg" alt=""
                                                    srcset="">
                                                Meu perfil </a>
                                            <a href='favoritos.php'> <img src="img/favorite.svg" alt="" srcset=""> Favoritos
                                            </a>
                                            <a href='#'> <img src="img/history.svg" alt="" srcset=""> Histórico/Compras
                                            </a>
                                        </li>
                                        <li class="vender-bloco"><a href='vender.php'> <img src="img/sell.svg" alt="" srcset="">
                                                Vender</a></li>
                                        <li class="ajuda-bloco"><a href='#'> <img src="img/question.svg" alt="" srcset="">
                                                Perguntas</a></li>
                                        <li class="sair-button"><a href='logout.php'> <img src="img/logout.svg" alt=""
                                                    srcset="">
                                                sair </a></li>
                                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                                    </ul>

                                    <?php
                                } else {
                                    echo "<a href='login.php' class='cursor'> Login </a>";
                                }
                                ?>
                            </li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <!--coteudo principal da pagina-->
            <main class="conteudo">

                <main>
                    <section class="produto">
                        <h1>
                            <?= $selecionar['nome'] ?>
                        </h1>
                        <section style="height: 350px;" id="minhaImagem">

                        </section>
                        <ul class="imgs_opcoes">
                            <form method='post'>
                                <?php
                                //pega todas as IMGs do banco que ele colocou no produto e mostra para ele
                                $i = 1;
                                while ($x = $selecionarImgs->fetch_assoc() and $i <= 4) {
                                    $nome = $x['caminho_imagem'];
                                    ?>
                                    <div class="img_cards">
                                        <!--Botões para editar a imagem ou deleta-la-->
                                        <div class="img_cards_buttons">
                                            <button class="btn_edit" value="<?= $x['caminho_imagem'] ?>" name="del"><img
                                                    src="img/trash.svg" alt=""></button>
                                            <a href='editar-img.php?nome=<?= $nome ?>&id=<?= $id ?>' class="btn_edit"
                                                name="edit"><img src="img/edit_red.svg" alt=""></a>
                                        </div>
                                        <!--cards interativos para mostrar as img-->
                                        <li class='itens-<?= $i ?>' onclick='myFunction<?= $i ?>()'>
                                            <img src="<?= $x['caminho_imagem'] ?>" alt="<?= $x['caminho_imagem'] ?>">
                                            <input type="hidden" value='<?= $x['caminho_imagem'] ?>' id="img-<?= $i ?>">
                                        </li>
                                    </div>
                                    <?php
                                    $i++;
                                }

                                //opção de adicionar imgs caso ele não tenha colocados o tamamho possivel
                                $selecionarImgs->fetch_assoc();
                                if ($selecionarImgs->num_rows < 4) {
                                    ?>
                                    <div class="img_cards add_card">
                                        <a href='add-img.php?i=<?= $i ?>&id=<?= $id ?>'>
                                            <img src="img/plus.svg" alt="">
                                        </a>
                                    </div>
                                    <?php
                                }

                                if (isset($_POST['del'])) {
                                    $caminho = $_POST['del'];
                                    if (file_exists($caminho)) {
                                        if (unlink($caminho)) {
                                            $caminhoEscapado = $conn->real_escape_string($caminho);
                                            $deleteImg = $conn->query("DELETE FROM imagens_prod WHERE caminho_imagem = '$caminhoEscapado'");
                                            echo '<script>window.location = ' . "'editar-produto.php?id=$id'" . ';</script>';
                                        }
                                    }
                                }

                                ?>
                            </form>
                        </ul>
                    </section>
                    <!-- formulario de edição dos dados do produto -->
                    <section class="alterar-dados">
                        <h1>Editar Produto</h1>
                        <form action="" method="post">

                            <ul>
                                <li class="das">
                                    <p>Categoria</p>
                                    <div>
                                        <?php
                                        if ($selecionar['ID_categ'] == 1) {
                                            ?>
                                            <input hidden id='categ_input_madeira' onchange="trocar1()" checked type="radio"
                                                name="categ" value='1'>
                                            <label id="categ_madeira" for='categ_input_madeira'><img src="img/wood-pile.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_plastico' onchange="trocar2()" type="radio"
                                                name="categ" value='2'>
                                            <label id="categ_plastico" for='categ_input_plastico'><img src="img/plastic.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_vidro' onchange="trocar3()" type="radio" name="categ"
                                                value='3'>
                                            <label id="categ_vidro" for='categ_input_vidro'><img src="img/glass-filled.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_metal' onchange="trocar4()" type="radio" name="categ"
                                                value='4'>
                                            <label id="categ_metal" for='categ_input_metal'><img
                                                    src="img/empty-metal-bucket.svg" alt=""></label>
                                            <input hidden id='categ_input_pvc' onchange="trocar5()" type="radio" name="categ"
                                                value='5'>
                                            <label id="categ_pvc" for='categ_input_pvc'><img src="img/pipe.svg" alt=""></label>
                                            <script>
                                                document.getElementById("categ_madeira")
                                                document.getElementById("categ_plastico").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_vidro").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_metal").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_pvc").style.webkitFilter = "grayscale(100%)";
                                            </script>
                                            <?php
                                        } elseif ($selecionar['ID_categ'] == 2) {
                                            ?>
                                            <input hidden id='categ_input_madeira' onchange="trocar1()" type="radio"
                                                name="categ" value='1'>
                                            <label id="categ_madeira" for='categ_input_madeira'><img src="img/wood-pile.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_plastico' onchange="trocar2()" checked type="radio"
                                                name="categ" value='2'>
                                            <label id="categ_plastico" for='categ_input_plastico'><img src="img/plastic.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_vidro' onchange="trocar3()" type="radio" name="categ"
                                                value='3'>
                                            <label id="categ_vidro" for='categ_input_vidro'><img src="img/glass-filled.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_metal' onchange="trocar4()" type="radio" name="categ"
                                                value='4'>
                                            <label id="categ_metal" for='categ_input_metal'><img
                                                    src="img/empty-metal-bucket.svg" alt=""></label>
                                            <input hidden id='categ_input_pvc' onchange="trocar5()" type="radio" name="categ"
                                                value='5'>
                                            <label id="categ_pvc" for='categ_input_pvc'><img src="img/pipe.svg" alt=""></label>
                                            <script>
                                                document.getElementById("categ_madeira").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_plastico")
                                                document.getElementById("categ_vidro").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_metal").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_pvc").style.webkitFilter = "grayscale(100%)";
                                            </script>
                                            <?php
                                        } elseif ($selecionar['ID_categ'] == 3) {
                                            ?>
                                            <input hidden id='categ_input_madeira' onchange="trocar1()" type="radio"
                                                name="categ" value='1'>
                                            <label id="categ_madeira" for='categ_input_madeira'><img src="img/wood-pile.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_plastico' onchange="trocar2()" type="radio"
                                                name="categ" value='2'>
                                            <label id="categ_plastico" for='categ_input_plastico'><img src="img/plastic.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_vidro' onchange="trocar3()" type="radio" name="categ"
                                                checked value='3'>
                                            <label id="categ_vidro" for='categ_input_vidro'><img src="img/glass-filled.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_metal' onchange="trocar4()" type="radio" name="categ"
                                                value='4'>
                                            <label id="categ_metal" for='categ_input_metal'><img
                                                    src="img/empty-metal-bucket.svg" alt=""></label>
                                            <input hidden id='categ_input_pvc' onchange="trocar5()" type="radio" name="categ"
                                                value='5'>
                                            <label id="categ_pvc" for='categ_input_pvc'><img src="img/pipe.svg" alt=""></label>
                                            <script>
                                                document.getElementById("categ_madeira").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_plastico").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_vidro")
                                                document.getElementById("categ_metal").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_pvc").style.webkitFilter = "grayscale(100%)";
                                            </script>
                                            <?php
                                        } elseif ($selecionar['ID_categ'] == 4) {
                                            ?>
                                            <input hidden id='categ_input_madeira' onchange="trocar1()" type="radio"
                                                name="categ" value='1'>
                                            <label id="categ_madeira" for='categ_input_madeira'><img src="img/wood-pile.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_plastico' onchange="trocar2()" type="radio"
                                                name="categ" value='2'>
                                            <label id="categ_plastico" for='categ_input_plastico'><img src="img/plastic.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_vidro' onchange="trocar3()" type="radio" name="categ"
                                                value='3'>
                                            <label id="categ_vidro" for='categ_input_vidro'><img src="img/glass-filled.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_metal' onchange="trocar4()" checked type="radio"
                                                name="categ" value='4'>
                                            <label id="categ_metal" for='categ_input_metal'><img
                                                    src="img/empty-metal-bucket.svg" alt=""></label>
                                            <input hidden id='categ_input_pvc' onchange="trocar5()" type="radio" name="categ"
                                                value='5'>
                                            <label id="categ_pvc" for='categ_input_pvc'><img src="img/pipe.svg" alt=""></label>
                                            <script>
                                                document.getElementById("categ_madeira").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_plastico").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_vidro").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_metal")
                                                document.getElementById("categ_pvc").style.webkitFilter = "grayscale(100%)";
                                            </script>
                                            <?php
                                        } elseif ($selecionar['ID_categ'] == 5) {
                                            ?>
                                            <input hidden id='categ_input_madeira' onchange="trocar1()" type="radio"
                                                name="categ" value='1'>
                                            <label id="categ_madeira" for='categ_input_madeira'><img src="img/wood-pile.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_plastico' onchange="trocar2()" type="radio"
                                                name="categ" value='2'>
                                            <label id="categ_plastico" for='categ_input_plastico'><img src="img/plastic.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_vidro' onchange="trocar3()" type="radio" name="categ"
                                                value='3'>
                                            <label id="categ_vidro" for='categ_input_vidro'><img src="img/glass-filled.svg"
                                                    alt=""></label>
                                            <input hidden id='categ_input_metal' onchange="trocar4()" type="radio" name="categ"
                                                value='4'>
                                            <label id="categ_metal" for='categ_input_metal'><img
                                                    src="img/empty-metal-bucket.svg" alt=""></label>
                                            <input hidden id='categ_input_pvc' onchange="trocar5()" checked type="radio"
                                                name="categ" value='5'>
                                            <label id="categ_pvc" for='categ_input_pvc'><img src="img/pipe.svg" alt=""></label>
                                            <script>
                                                document.getElementById("categ_madeira").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_plastico").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_vidro").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_metal").style.webkitFilter = "grayscale(100%)";
                                                document.getElementById("categ_pvc")
                                            </script>
                                            <?php
                                        }
                                        ?>
                                    </div>

                                    <script>
                                        var categ_madeira = document.getElementById("categ_madeira")
                                        var categ_plastico = document.getElementById("categ_plastico")
                                        var categ_vidro = document.getElementById("categ_vidro")
                                        var categ_metal = document.getElementById("categ_metal")
                                        var categ_pvc = document.getElementById("categ_pvc")

                                        function trocar1() {
                                            categ_madeira.style.webkitFilter = "grayscale(0%)";
                                            categ_plastico.style.webkitFilter = "grayscale(100%)";
                                            categ_vidro.style.webkitFilter = "grayscale(100%)";
                                            categ_metal.style.webkitFilter = "grayscale(100%)";
                                            categ_pvc.style.webkitFilter = "grayscale(100%)";
                                        }
                                        function trocar2() {
                                            categ_madeira.style.webkitFilter = "grayscale(100%)";
                                            categ_plastico.style.webkitFilter = "grayscale(0%)";
                                            categ_vidro.style.webkitFilter = "grayscale(100%)";
                                            categ_metal.style.webkitFilter = "grayscale(100%)";
                                            categ_pvc.style.webkitFilter = "grayscale(100%)";
                                        }
                                        function trocar3() {
                                            categ_madeira.style.webkitFilter = "grayscale(100%)";
                                            categ_plastico.style.webkitFilter = "grayscale(100%)";
                                            categ_vidro.style.webkitFilter = "grayscale(0%)";
                                            categ_metal.style.webkitFilter = "grayscale(100%)";
                                            categ_pvc.style.webkitFilter = "grayscale(100%)";
                                        }
                                        function trocar4() {
                                            categ_madeira.style.webkitFilter = "grayscale(100%)";
                                            categ_plastico.style.webkitFilter = "grayscale(100%)";
                                            categ_vidro.style.webkitFilter = "grayscale(100%)";
                                            categ_metal.style.webkitFilter = "grayscale(0%)";
                                            categ_pvc.style.webkitFilter = "grayscale(100%)";
                                        }
                                        function trocar5() {
                                            categ_madeira.style.webkitFilter = "grayscale(100%)";
                                            categ_plastico.style.webkitFilter = "grayscale(100%)";
                                            categ_vidro.style.webkitFilter = "grayscale(100%)";
                                            categ_metal.style.webkitFilter = "grayscale(100%)";
                                            categ_pvc.style.webkitFilter = "grayscale(0%)";
                                        }
                                    </script>
                                </li>
                                <li class="textfield">
                                    <label for="nome"> Valor do produto</label>
                                    <input id="nome" type="text" value="<?= $selecionar['nome'] ?>" name="nome_prod"
                                        placeholder="Digite Aqui..." autofocus required>
                                </li>
                                <li class="textfield">
                                    <label for="preco"> Valor do produto</label>
                                    <input id="preco" type="text" value="<?= $selecionar['preco'] ?>" name="preco"
                                        placeholder="Digite Aqui..." autofocus required>
                                </li>
                                <li class="textfield">
                                    <label for="quantidade"> Quatidade do produto</label>
                                    <input id="quantidade" type="text" value="<?= $selecionar['quantidade'] ?>"
                                        name="quantidade" placeholder="Digite Aqui..." autofocus required>
                                </li>
                                <li class="textfield">
                                    <label for="descricao"> Descrição do produto*</label>
                                    <textarea id="descricao" name="descricao" class="textfield" cols="30"
                                        rows="7"><?= $selecionar['descricao'] ?></textarea>
                                </li>

                            </ul>
                            <div action="" class="usos_area" method="post">
                                <!-- alterações que ele pode fazer -->
                                <?php
                                // verifica qual o estado do produto atual e gera duas possibilidade dependendo do estado
                                if ($selecionar["ativo"] == 1) {
                                    echo '<button name="desativar" type="submit">Desativar</button>';
                                } else {
                                    echo '<button name="ativar" type="submit">Ativar</button>';
                                }
                                ?>
                                <button type="submit" name="excluir">Excluir</button>
                                <button type="submit" name="salvar">salvar alterações</button>
                            </div>
                        </form>
                    </section>

                </main>
            </main>
            <!--menu-lateral-->
            <aside class="menu-lateral">
                <div class="title">
                    <img style="cursor: pointer;" src="img/hamburger.png" alt="" onclick="clickMenu()">
                    <p id='display'>Minha Conta</p>
                </div>
                <ul>
                    <a href="perfil.php">
                        <li class="disseletec-topic"><img src="img/user-gray.svg" alt="perfil-icon">
                            <p>Meu Perfil</p>
                        </li>
                    </a>
                    <a href="favoritos.php">
                        <li class="disseletec-topic"><img src="img/heart-gray.svg" alt="favoritos-icon">
                            <p>Favoritos</p>
                        </li>
                    </a>
                    <a href="">
                        <li class="disseletec-topic"><img src="img/bag-gray.svg" alt="historico-icon">
                            <p>Historico/Compras</p>
                        </li>
                    </a>
                    <a href="vender.php">
                        <li class="seletec-topic"><img src="img/tag-gray.svg" alt="vender-icon">
                            <p>Vender</p>
                        </li>
                    </a>
                </ul>
            </aside>
        </div>
        <script src="js/img.js"></script>
        <script src="js/js.js"></script>
    </body>

    </html>
    <?php
    // caso ele não esteje logado redireciona-o para o login
} else {
    include_once("login.php");
}
?>