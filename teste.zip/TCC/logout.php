<?php
include("conexao/conexao.php");
$_SESSION['nome'] = '';

// unset($_SESSION['nome'], $_SESSION['email']);
header("Location: ecommerce.php");

?>