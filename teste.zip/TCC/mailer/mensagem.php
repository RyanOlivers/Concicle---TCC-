<?php
include('conexao.php');
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="Content-Type" content="text/html;">
    <link rel="stylesheet">
    <title> mensagem para o user </title>
</head>
<style>
    * {
        font-size: 12px;
        font-family: 'Times New Roman', Times, serif;
    }

    p {
        font-size: 14px;
        color: red;
    }
</style>

<body>


    <h1> CONFIRMAÇÃO DE EMAIL - CONCICLE</h1>
    <h3>Olá usuario, se você recebeu essa mensagem por estar
        tentando fazer um cadastro na nossa plataforma Concicle
        <p>
            Insira o código de verificação que é solicitado.
        </p>
        Caso não esteja tentando se cadastrar em nenhuma aplicação, por favor apenas ignore.
        
    </h3>


</body>

</html>