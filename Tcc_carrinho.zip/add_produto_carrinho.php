<?php
session_start();

$id_usuario = $_POST['id_usuario'];
$id_produto = $_POST['id_produto'];

include_once("conexao/conexao.php");

$check_query = "SELECT * FROM carrinho WHERE id_produto = '$id_produto' AND id_usuario = '$id_usuario'";
$check_result = mysqli_query($conn, $check_query);

if (mysqli_num_rows($check_result) == 0) {
    $insert_query = "INSERT INTO carrinho (id_produto, id_usuario) VALUES ('$id_produto', '$id_usuario')";
    $insert_result = mysqli_query($conn, $insert_query);

    if ($insert_result) {
        $_SESSION['add_carrinho'] == "inserido";
        echo "Registro inserido com sucesso.";
    } else {
        echo "Erro ao inserir o registro: " . mysqli_error($conn);
        $_SESSION['add_carrinho'] == "erro";
    }
} else {
    $_SESSION['add_carrinho'] == "ja_existe";
    echo "O registro já existe no carrinho.";
}

// Feche a conexão com o banco de dados
mysqli_close($conn);



?>