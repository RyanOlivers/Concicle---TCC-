//Ajax para adicionar um produto ao seu respectivo carrinho

$(document).ready(function() {
    $("#add_carrinho").click(function() {
        var id_produto = $("#id_produto").val();
        var id_usuario = $("#id_usuario").val();

        $.ajax({
            url: "add_produto_carrinho.php",
            type: "POST", 
            data: { id_produto: id_produto, id_usuario: id_usuario },
            success: function(response) {
                console.log(response); 
            },
            error: function(xhr, status, error) {
                console.log("Erro: " + error);
            }
        });
    });
});


$(document).ready(function() {
    $(".cart-svg-icon").click(function() {
        var svgIcon = $(this); // O elemento SVG clicado

        // Use as funções de travessia para encontrar os inputs correspondentes
        var id_produto = svgIcon.siblings("#id_produto_delete").val();
        var id_usuario = svgIcon.siblings("#id_usuario_delete").val();

        $.ajax({
            url: "delete_produto_carrinho.php",
            type: "POST", 
            data: { id_produto: id_produto, id_usuario: id_usuario },
            success: function(response) {
                console.log(response); 
            },
            error: function(xhr, status, error) {
                console.log("Erro: " + error);
            }
        });
    });
});


