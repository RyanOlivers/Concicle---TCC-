<?php

$id_usuario = $_POST['id_usuario'];
$id_produto = $_POST['id_produto'];

include_once("conexao/conexao.php");
$query = "DELETE FROM carrinho WHERE id_produto = '$id_produto' AND id_usuario = '$id_usuario' ";
$result = mysqli_query($conn, $query);


?>