var menu = document.getElementById("menu");

menu.addEventListener("mouseover", function() {
  menu.classList.remove("hide-menu");
});

menu.addEventListener("mouseout", function() {
  // verifica se a posição atual da rolagem da página é menor que (window.innerHeight * 0.1) antes de adicionar a classe "hide-menu"
  if (window.pageYOffset < (window.innerHeight * 0.1)) {
    menu.classList.add("hide-menu");
  }
});

window.addEventListener("scroll", function() {
  if (window.pageYOffset > (window.innerHeight * 0.1)) { /* 10vh corresponde a 10% da altura da janela de visualização */
    menu.classList.add("dark");
  } else {
    menu.classList.remove("dark");
  }
  
  // verifica se a posição atual da rolagem da página é menor que (window.innerHeight * 0.1) antes de adicionar a classe "hide-menu"
  if (window.pageYOffset < (window.innerHeight * 0.1)) {
    menu.classList.add("hide-menu");
  }
});


window.addEventListener("scroll", function() {
  if (window.pageYOffset > (window.innerHeight * 0.1)) { /* 10vh corresponde a 10% da altura da janela de visualização */
    menu.classList.add("dark");
  } else {
    menu.classList.remove("dark");
  }
});


function menu(params) {
  let menuMobile = document.querySelector('.mobile-menu')
  if (menuMobile.classList.contains('open')) {
      menuMobile.classList.remove('open')
  } else {
    menuMobile.classList.add('opens')
  }
}