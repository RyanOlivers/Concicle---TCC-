var elemento2 = document.getElementById("img-1").value;
var elemento = document.getElementById("minhaImagem");
elemento.style.backgroundImage = `url('${elemento2}')`;
elemento.style.backgroundRepeat = "no-repeat";
elemento.style.backgroundSize = "100%";
elemento.style.backgroundPosition = "center";
document.querySelector(".itens-1").style.backgroundColor = "#cecececc";
document.querySelector(".itens-2").style.backgroundColor = "";
document.querySelector(".itens-3").style.backgroundColor = "";
document.querySelector(".itens-4").style.backgroundColor = "";

function myFunction1() {
  var elemento2 = document.getElementById("img-1").value;
  var elemento = document.getElementById("minhaImagem");
  elemento.style.backgroundImage = `url('${elemento2}')`;
  elemento.style.backgroundRepeat = "no-repeat";
  elemento.style.backgroundSize = "100%";
  elemento.style.backgroundPosition = "center";
  document.querySelector(".itens-1").style.backgroundColor = "#cecececc";
  document.querySelector(".itens-2").style.backgroundColor = "";
  document.querySelector(".itens-3").style.backgroundColor = "";
  document.querySelector(".itens-4").style.backgroundColor = "";
}
function myFunction2() {
  var elemento2 = document.getElementById("img-2").value;
  var elemento = document.getElementById("minhaImagem");
  elemento.style.backgroundImage = `url('${elemento2}')`;
  elemento.style.backgroundRepeat = "no-repeat";
  elemento.style.backgroundSize = "100%";
  elemento.style.backgroundPosition = "center";
  document.querySelector(".itens-2").style.backgroundColor = "#cecececc";
  document.querySelector(".itens-1").style.backgroundColor = "";
  document.querySelector(".itens-3").style.backgroundColor = "";
  document.querySelector(".itens-4").style.backgroundColor = "";
}
function myFunction3() {
  var elemento2 = document.getElementById("img-3").value;
  var elemento = document.getElementById("minhaImagem");
  elemento.style.backgroundImage = `url('${elemento2}')`;
  elemento.style.backgroundRepeat = "no-repeat";
  elemento.style.backgroundSize = "100%";
  elemento.style.backgroundPosition = "center";
  document.querySelector(".itens-3").style.backgroundColor = "#cecececc";
  document.querySelector(".itens-2").style.backgroundColor = "";
  document.querySelector(".itens-1").style.backgroundColor = "";
  document.querySelector(".itens-4").style.backgroundColor = "";
}
function myFunction4() {
  var elemento2 = document.getElementById("img-4").value;
  var elemento = document.getElementById("minhaImagem");
  elemento.style.backgroundImage = `url('${elemento2}')`;
  elemento.style.backgroundRepeat = "no-repeat";
  elemento.style.backgroundSize = "100%";
  elemento.style.backgroundPosition = "center";
  document.querySelector(".itens-4").style.backgroundColor = "#cecececc";
  document.querySelector(".itens-2").style.backgroundColor = "";
  document.querySelector(".itens-3").style.backgroundColor = "";
  document.querySelector(".itens-1").style.backgroundColor = "";
}