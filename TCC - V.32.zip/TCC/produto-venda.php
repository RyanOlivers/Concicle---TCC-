<?php
include_once("conexao/conexao.php");

// define a zona de tempo a ser utilizada.
date_default_timezone_set('America/Sao_Paulo');
// echo"<pre>";
// print_r($_SESSION);
// echo "</pre>";
$erroComnet = "";
$id = $_GET["id"];
$query = "SELECT * FROM produto WHERE ID_prod = $id";
$result = $conn->query($query)->fetch_assoc();
// $x = $result->fetch_assoc();
$img = $conn->query("SELECT * from imagens_prod WHERE ID_prod = $id");
$img2 = $conn->query("SELECT * from imagens_prod WHERE ID_prod = $id")->fetch_assoc();
// $img_prod = $img['caminho_imagem'];
$ava = $conn->query("SELECT * from avaliacao WHERE ID_prod = $id");

// if(isset($_POST['payButton'])) {
//     $id_user = $_SESSION['id'];
//     Header("Location: order.php?id_prod=$id&id_user=$id_user");
// }

if (isset($_POST["add_comentario"])) {
    if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
        $id_user = $_SESSION['id'];
        $data = date('Y-m-d');
        $hora = date('H:i:s');
        $coment = $_POST["comentario_prod"];
        $avalia = $conn->query("INSERT INTO avaliacao (ID_usuario, ID_prod, data_av, hora_av, comentario) VALUES ('{$id_user}','{$id}','{$data}','{$hora}','{$coment}' ) ");
        header("location: produto-venda.php?id=$id");
    } else {
        $erroComnet = "Você precisa ter login para comentar";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/produto-venda.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/cart.css">
    <!-- <link rel="stylesheet" href="css/ecommerce.css"> -->

    <title>CONCICLE | Conscientize, Recicle & Receba</title>
</head>

<body>
    <nav>
        <ul class="a">
            <li class="logotipo">
                <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
            </li>
            <li class="usuario">
                <ul>
                    <li class="li-pai">
                        <?php
                        if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
                            $id_usuario = $_SESSION['id'];
                            echo "<p class='cursor dropdown-arrow'>" . $_SESSION['nome'] . "</p>";
                            ?>
                            <ul class='sub-menus'>
                                <li class="perfil">
                                    <a href="perfil.php">
                                        <?php
                                        $sql = $conn->query("SELECT * FROM imagens WHERE ID_user = '$id_usuario'")->fetch_assoc();
                                        echo "<img src='{$sql['caminho_imagem']}' alt=''>";
                                        ?>

                                        <div class="sub-text">
                                            <p class="p-ola"> Olá </p>
                                            <p class="p-name">
                                                <?= $_SESSION['nome'] ?>
                                            </p>
                                        </div>
                                    </a>
                                </li>

                                <li class="perfil-bloco"> <a href='perfil.php'> <img src="img/perfil.svg" alt="" srcset="">
                                        Meu perfil </a>
                                    <a href='favoritos.php'> <img src="img/favorite.svg" alt="" srcset=""> Favoritos </a>
                                    <a href='#'> <img src="img/history.svg" alt="" srcset=""> Histórico/Compras
                                    </a>
                                </li>
                                <li class="vender-bloco"><a href='vender.php'> <img src="img/sell.svg" alt="" srcset="">
                                        Vender</a></li>
                                <li class="ajuda-bloco"><a href='#'> <img src="img/question.svg" alt="" srcset="">
                                        Perguntas</a></li>
                                <li class="sair-button"><a href='logout.php'> <img src="img/logout-gray.svg" alt=""
                                            srcset=""> sair </a></li>
                            </ul>

                            <?php
                        } else {
                            echo "<a href='login.php' class='cursor'>Entrar/Cadastrar</a>";
                        }
                        ?>
                    </li>
                    <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                </ul>
            </li>
        </ul>
        <ul class="usos">
            <li class="li-pai">
                <span class="" style="cursor:pointer;"> Categorias </span>
                <ul class='sub-menus'>
                    <li class="produtos"> <a href='http://'> Madeira </a>
                        <a href='http://'> Plástico/PET </a>
                        <a href='http://'> Metal </a>
                        <a href='http://'> Vidro </a>
                        <a href='http://'> PVC </a>
                    </li>
                    <!-- Verificar se vamos puxar as categorias do banco ou não; -->
                </ul>
            </li>
            <li class="li-pai">
                <a href="#">Ofertas</a>
            </li>
            <li class="search-bar li-pai">
                <input type="text" name="pesquisa" id="pesquisa" placeholder="Pesquisar">
            </li>
            <li class="li-pai">
                <a href="#" onclick="showCart()">
                    <img src="img/shopping-cart.svg" alt="carrinho">
                </a>
            </li>
        </ul>
    </nav>

    <main>
        <section id="container">
            <main class="conteudo_principal">
                <section style="height: 350px" id="minhaImagem">

                </section>
                <ul class="imgs_opcoes">
                    <?php
                    $i = 1;
                    while ($x = $img->fetch_assoc() and $i <= 4) {
                        ?>
                        <li class='itens-<?= $i ?>' onclick='myFunction<?= $i ?>()'>
                            <img src="<?= $x['caminho_imagem'] ?>" alt="<?= $x['caminho_imagem'] ?>">
                            <input type="hidden" value='<?= $x['caminho_imagem'] ?>' id="img-<?= $i ?>">
                        </li>
                        <?php
                        $i++;
                    }
                    ?>
                </ul>
                <form method="post" class="comprar">
                    <button type="submit" name='add_carrinho'>
                        Adicionar ao Carrinho
                    </button>
                </form>
                <?php
                if (isset($_POST['add_carrinho'])) {
                    $id_user = $_SESSION['id'];
                    $existe = $conn->query("SELECT * FROM carrinho_prod WHERE ID_prod = $id");
                    echo$existe->num_rows;
                    if ($existe->num_rows == 0) {
                        $insertQuery = $conn->query("INSERT INTO carrinho_prod (ID_prod, ID_usuario, qtd) VALUES ($id, $id_user, 1)");
                        
                    } else {
                        $existe = $conn->query("SELECT * FROM carrinho_prod WHERE ID_prod = $id")->fetch_assoc();    
                        $qtd = $existe['qtd'] + 1;
                        $updateCarrinho = $conn->query("UPDATE carrinho_prod SET qtd = $qtd WHERE ID_prod = $id and ID_usuario = $id_user");
                    }
                }

                ?>
            </main>
            <aside class="descrição-comentarios">
                <header>
                    <h1>
                        <?= $result['nome'] ?>
                    </h1>
                    <p>
                        R$
                        <?= $result['preco'] ?>
                    </p>
                </header>
                <section>
                    <h2>descrição</h2>
                    <p>
                        <?= $result['descricao'] ?>
                    </p>
                </section>
                <section clas="comentarios">

                </section>
                <section class="textarea">
                    <form action="" method="POST" class="coment">
                        <h2>comente sobre o produto</h2>
                        <textarea required name="comentario_prod" cols="30" rows="5" class="cometario"
                            v-model="inputValue"></textarea>
                        <button type="submit" name='add_comentario' @click="animate" v-if="!inputValue">Adicionar
                            comentário</button>
                        <p v-if="animationActive" id="messageDiv" class="animation"
                            style="color: Red; margin-top: 15px; margin-left: 15px; ">
                            <?= $erroComnet ?>
                        </p>
                    </form>
                </section>
                <?php
                if ($ava->num_rows > 0) {
                    while ($row = $ava->fetch_assoc()) {
                        //nome do user
                        $id_userP = $row["ID_usuario"];
                        $sql = "SELECT * FROM usuario WHERE id_usuario = $id_userP";
                        $result_sql = $result_sql = $conn->query($sql)->fetch_assoc();
                        $nome_user = $result_sql["nome"] . " " . $result_sql["sobrenome"];
                        ?>
                        <p style="color: Black; margin-top: 15px; margin-left: 15px;">
                            <?= $nome_user ?>
                        </p>
                        <p class="ApComent">
                            <?= $row["comentario"] ?>
                        </p>
                        <?php
                    }
                } else {
                    $mensg = "Esse produto ainda não foi avaliado";
                    ?>
                    <p class="ApComent">
                        <?= $mensg ?>
                    </p>
                    <?php
                }
                ?>
            </aside>
        </section>
    </main>
    <script type="text/javascript">
        // Função para ocultar a mensagem após 5 segundos (5000 milissegundos)
        setTimeout(function () {
            var messageDiv = document.getElementById('messageDiv');
            if (messageDiv) {
                messageDiv.style.display = 'none';
            }
        }, 3000); // 3000 milissegundos = 3 segundos
    </script>
    <script src="js/img.js"></script>
    <!--VUE JS-->
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.14"></script>
    <script>
        export default {
            data() {
                return {
                    inputValue: '',
                    animationActive: false
                };
            },
            methods: {
                animate() {
                    if (!this.inputValue) {
                        // Define um atraso de 2 segundos (2000 milissegundos) antes de iniciar a animação
                        setTimeout(() => {
                            this.animationActive = true;
                            // Lógica da animação

                            // Define um atraso de 1 segundo (1000 milissegundos) para desativar a animação
                            setTimeout(() => {
                                this.animationActive = false;
                            }, 1000);
                        }, 2000);
                    }
                }
            }
        };
    </script>
    <style>
        .animation {
            /* Estilos da animação */
            color: red;
            animation: example 1s infinite;
        }

        @keyframes example {
            0% {
                transform: scale(1);
            }

            50% {
                transform: scale(1.5);
            }

            100% {
                transform: scale(1);
            }
        }
    </style>
</body>

</html>