<?php
include_once("conexao/conexao.php");
if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
    $id_usuario = $_SESSION['id'];
    $selectPerfil = $conn->query("SELECT * FROM usuario WHERE ID_usuario = $id_usuario")->fetch_assoc();
    $selectImgPerfil = $conn->query("SELECT * FROM imagens WHERE ID_user= $id_usuario")->fetch_assoc();
    $img = $selectImgPerfil['caminho_imagem'];
    if (isset($_POST['salvar'])) {
        $nome = $_POST['nome'];
        $sobrenome = $_POST['sobrenome'];
        $email = $_POST['email'];
        $CPF = $_POST['cpf'];
        $cargo = $selectPerfil['cargo'];
        $_SESSION['link'] = "localhost/TCC/cadastro-step-Verif-atualizar.php?id=$id_usuario&email=$email&nome=$nome&cpf=$CPF&sobrenome=$sobrenome";
        if ($email != $selectPerfil['email']) {
            header("location: cadastro-step-Envio-atualizar.php?email=$email&nome_user=$nome");
        } else {
            $update_ = $conn->query("UPDATE usuario SET nome = '$nome', sobrenome = '$sobrenome', email = '$email', cpf = '$CPF' WHERE ID_usuario = $id_usuario");
            $_SESSION['nome'] = $nome;
            $_SESSION['email'] = $email;
            $_SESSION['sobrenome'] = $sobrenome;
            echo "<script>
                    window.location = 'editar-perfil.php?'
                </script>";

        }
    }
    ?>

    <!DOCTYPE html>
    <html lang="pt-br">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
        <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
        <link rel="stylesheet" href="css/editar-perfil.css">
        <link rel="stylesheet" href="css/footer.css">
        <link rel="stylesheet" href="css/menu.css">

        <title>CONCICLE | Conscientize, Recicle & Receba</title>
    </head>

    <body>
        <div id="container">
            <nav>
                <ul class="a">
                    <li class="logotipo">
                        <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                    </li>
                    <li class="usuario">
                        <ul>
                            <li id="cursor">
                                <?php
                                if (isset($selectPerfil['nome']) && $selectPerfil['nome'] != '') {
                                    echo "<p class='cursor dropdown-arrow'>" . $selectPerfil['nome'] . "</p>";
                                    ?>
                                    <ul class='sub-menus'>
                                        <li class="perfil">
                                            <a href="perfil.php">
                                                <?php
                                                $sql = $conn->query("SELECT * FROM imagens WHERE ID_user = '$id_usuario'")->fetch_assoc();
                                                echo "<img src='{$sql['caminho_imagem']}' alt=''>";
                                                ?>

                                                <div class="sub-text">
                                                    <p class="p-ola"> Olá </p>
                                                    <p class="p-name">
                                                        <?= $selectPerfil['nome'] ?>
                                                    </p>
                                                </div>
                                            </a>
                                        </li>

                                        <li class="perfil-bloco"> <a href='perfil.php'> <img
                                                    src="img/perfil.svg" alt="" srcset=""> Meu perfil </a>
                                            <a href='favoritos.php'> <img src="img/favorite.svg" alt=""
                                                    srcset=""> Favoritos
                                            </a>
                                            <a href='#'> <img src="img/history.svg" alt="" srcset=""> Histórico/Compras
                                            </a>
                                        </li>
                                        <li class="vender-bloco"><a href='vender.php'> <img
                                                    src="img/sell.svg" alt="" srcset="">
                                                Vender</a></li>
                                        <li class="ajuda-bloco"><a href='faq.php'> <img
                                                    src="img/question.svg" alt="" srcset="">
                                                Perguntas</a></li>
                                        <li class="sair-button"><a href='logout.php'> <img
                                                    src="img/logout-gray.svg" alt="" srcset=""> sair </a></li>
                                    </ul>

                                    <?php
                                } else {
                                    echo "<a href='login.php' class='cursor'>Entrar/Cadastrar</a>";
                                }
                                ?>
                            </li>
                            <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
            <main>
                <section class="perfil-img-area">
                    <div class="header">
                        <h1>Bem vindo:</h1>
                        <p>
                            <?= $selectPerfil['nome'] ?>
                        </p>
                    </div>
                    <div style="background: url('<?= $img ?>');background-repeat: no-repeat;background-position: center;background-size: 100%;" class="img-perfil">
                        <div>
                            <a href="editar-img-perfil.php?id=<?=$id_usuario?>&nome=<?=$img?>" class="editar-img">
                                <img src="img/edit_red.svg" alt="">
                                <p>editar img</p>
                            </a>

                        </div>
                    </div>
                    <!-- <img src="<?= $img ?>" alt="" srcset=""> -->
                </section>
                <section class="perfil-area">
                    <h1>Editar seus dados</h1>
                    <form action="" method="post">
                        <div class="textfield">
                            <label for="nome"> Nome</label>
                            <input type="text" id="nome" name="nome" value="<?= $selectPerfil['nome'] ?>"
                                placeholder="Digite Aqui..." autofocus required>
                        </div>
                        <div class="textfield">
                            <label for="sobrenome"> Sobrenome</label>
                            <input type="text" id="sobrenome" name="sobrenome" value="<?= $selectPerfil['sobrenome'] ?>"
                                placeholder="Digite Aqui..." autofocus required>
                        </div>
                        <div class="textfield">
                            <label for="email"> Email</label>
                            <input type="text" id="email" name="email" value="<?= $selectPerfil['email'] ?>"
                                placeholder="Digite Aqui..." autofocus required>
                        </div>
                        <div class="textfield">
                            <label for="cpf"> CPF</label>
                            <input type="password" id="cpf" name="cpf" value="<?= $selectPerfil['CPF'] ?>"
                                placeholder="Digite Aqui..." autofocus required>
                            <p class="mostrar">mostrar</p>
                        </div>
                        <script>
                            var mostrar = document.getElementById('cpf');
                            var click = document.querySelector(".mostrar");
                            var ocutar = false;
                            click.style.color = "#000"
                            click.style.cursor = "pointer"

                            click.addEventListener("click", function showCpf() {
                                ocutar = !ocutar
                                if (ocutar) {
                                    mostrar.type = "text"
                                } else {
                                    mostrar.type = "password"
                                }
                            })
                        </script>
                        <div class="buttons">
                            <button name="excluir" class="" type="submit">excluir</button>
                            <button name="salvar" class="" type="submit">salvar</button>
                            <button name="salvar" class="" type="submit" >Voltar</button>
                        </div>
                    </form>
                </section>
            </main>
            <aside class="menu-lateral">
                <div class="title">
                    <img style="cursor: pointer;" src="img/hamburger.png" alt="" onclick="clickMenu()">
                    <p id='display'>Minha Conta</p>
                </div>
                <ul>
                    <a href="perfil.php">
                        <li class="seletec-topic"><img src="img/user-gray.svg" alt="perfil-icon">
                            <p>Meu Perfil</p>
                        </li>
                    </a>
                    <a href="favoritos.php">
                        <li class="disseletec-topic"><img src="img/heart-gray.svg" alt="favoritos-icon">
                            <p>Favoritos</p>
                        </li>
                    </a>
                    <a href="">
                        <li class="disseletec-topic"><img src="img/bag-gray.svg" alt="historico-icon">
                            <p>Historico/Compras</p>
                        </li>
                    </a>

                    <?php
                    if ($selectPerfil['cargo'] == 2) {
                        ?>
                        <a href="vender.php">
                            <li class="disseletec-topic"><img src="img/tag-gray.svg" alt="vender-icon">
                                <p>Vender</p>
                            </li>
                        </a>
                        <?php
                    }
                    ?>
                </ul>
            </aside>
        </div>
    </body>
    <script src="js/js.js"></script>

    </html>
    <?php
} else {
    header("location: login.php");
    // print_r($_SESSION);
} ?>