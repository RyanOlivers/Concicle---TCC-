document.getElementById("valorInput").value = document.getElementById("valorProduto").value;
let botao = document.querySelector(".btn")
let checkbox_madeira = document.getElementById("madeira");
let checkbox_metal = document.getElementById("metal");
let checkbox_plasticoPet = document.getElementById("plasticoPet");
let checkbox_vidro = document.getElementById("vidro");
let checkbox_pvc = document.getElementById("pvc");

function valorSelecionado(valor) {
    var valorInput = document.getElementById("valorInput");
    valorInput.value = valor;
    if (valorInput.value > 0) {
        button()
    } else {
        buttonOff();
    }
}
function button() {
    botao.style.display = 'block'
    // botao.textContent = 'aplicar';
    // botao.name = "filtrar";
    // botao.type = "submit";
    botao.style.color = '#000'
    botao.style.padding = '5px'
    botao.style.backgroundColor = 'trasparent'
}
function buttonOff() {
    botao.style.display = 'none';
}

let checkboxes = [checkbox_madeira, checkbox_metal, checkbox_plasticoPet, checkbox_vidro, checkbox_pvc];

function verificarCheckboxes() {
    let peloMenosUmMarcado = checkboxes.some(function(checkbox) {
        return checkbox.checked;
    });

    if (peloMenosUmMarcado) {
        button();
    } else {
        buttonOff();
    }
}

checkboxes.forEach(function(checkbox) {
    checkbox.addEventListener("change", verificarCheckboxes);
});
verificarCheckboxes();