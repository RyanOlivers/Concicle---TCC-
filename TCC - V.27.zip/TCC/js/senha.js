function senhaforte() {
    var senha = document.getElementById('senha').value;
    var lista = document.getElementById("minhaLista");
    var forca = 0;
    document.getElementById('Result').innerHTML = "Para criar uma senha segura siga as instrução: ";

    if (senha.length > 8) {
        forca += 15;
        item1.classList.add("cor-alterada");
    } else if (senha.length < 8) {
        item1.classList.remove("cor-alterada");
    }


    if ((senha.match(/[1-9]/))) {
        forca += 15;
        item3.classList.add("cor-alterada");
    } else if ((!senha.match(/[1-9]/))) {
        item3.classList.remove("cor-alterada");
    }

    if ((senha.match(/[A-Z]+/))) {
        forca += 20;
        item2.classList.add("cor-alterada");
    } else if ((!senha.match(/[A-Z]+/))) {
        item2.classList.remove("cor-alterada");
    }



    if (senha.match(/[@#$%&.*]/)) {
        forca += 30;
        item4.classList.add("cor-alterada");
    } else if (!senha.match(/[@#$%&;.*]/)) {
        item4.classList.remove("cor-alterada");
    }

    mostrarForca(forca);
    mostrarCondi(lista);

}

function mostrarForca(forca) {
    //document.getElementById("result").innerHTML = "forca " + forca;
    if (forca < 30) {
        document.getElementById("Errosenha").innerHTML = "Sua senha está: <span style='color: #ff0000'> Fraca </span>";

    } else if ((forca >= 30) && (forca < 70)) {
        document.getElementById("Errosenha").innerHTML = "Sua senha está: <span style='color: #FFD700'> Média </span>";

    } else if ((forca >= 80) && (forca < 100)) {
        document.getElementById("Errosenha").innerHTML = "Sua senha está: <span style='color: #7FFF00'> Forte </span>";
    }
}

function mostrarCondi(lista) {
    document.getElementById("minhaLista").innerHTML;
    document.getElementById("item1").innerHTML;
    document.getElementById("item2").innerHTML;
    document.getElementById("item3").innerHTML;
    document.getElementById("item4").innerHTML;
    if (lista.classList.contains("escondido")) {
        // Remove a classe "escondido" para mostrar a lista
        lista.classList.remove("escondido");
    }
    if (item1.classList.contains("escondido")) {
        // Remove a classe "escondido" para mostrar a lista
        item1.classList.remove("escondido");
    }
    if (item2.classList.contains("escondido")) {
        // Remove a classe "escondido" para mostrar a lista
        item2.classList.remove("escondido");
    }
    if (item3.classList.contains("escondido")) {
        // Remove a classe "escondido" para mostrar a lista
        item3.classList.remove("escondido");
    }
    if (item4.classList.contains("escondido")) {
        // Remove a classe "escondido" para mostrar a lista
        item4.classList.remove("escondido");
    }

}


function vamo() {
    if ((forca >= 50) || (forca <= 100)) {
        alert("Senha enviada");
    } else {
        alert("Senha não pode ser enviada");
    }
}