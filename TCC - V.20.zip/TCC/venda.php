<?php
    include_once("conexao/conexao.php");
    $id = $_GET["id"];
    $query = "SELECT * FROM produto WHERE ID_prod = $id";
    $result = $conn->query($query);
    $x = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/venda.css">
    <title>CONCICLE | Produto Exemplo</title>
</head>

<body>
    <div id="container">
    <nav>
        <ul class="a">
                <li class="logotipo">
                    <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li class="li-pai">
                            <?php
                                include_once("conexao/conexao.php");
                                if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
                                    echo "<p class='cursor dropdown-arrow'>" . $_SESSION['nome'] . "</p>";
                            ?>
                                    <ul class='sub-menus'>
                                        <li class="perfil">
                                            <a href="perfil.php">
                                                <img src="img/shopping-cart.svg" alt="">
                                                <div class="sub-text">
                                                    <p>Olá</p>
                                                    <p><?= $_SESSION['nome']?></p>
                                                </div>
                                            </a>
                                        </li>

                                        <li><a href='http://'>Products 1</a></li>
                                        <li><a href='http://'>Products 2</a></li>
                                        <li><a href='logout.php'>SAIR</a></li>
                                    </ul>
                            
                            <?php
                                } else {
                                    echo "<a href='login.php' class='cursor'>Login</a>";
                                }
                            ?>
                        </li>
                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>

        <div class="conteudo">
            <section class="prod">
                <a class="back" href="index.php"></a>
                <div class="prod-img">
                    <div id="minhaImagem"
                        style="background-image: url('img/paper bin.png'); background-position: center; background-repeat: no-repeat;">

                    </div>
                    <ul class="varias-fotos">
                        <li class="itens-1" onclick="myFunction1()">
                            <input type="button" name="item-1" id="item-1" hidden>
                            <label for="item-1"><img src="img/blue-bin.png" alt=""></label>
                        </li>
                        <li class="itens-2" onclick="myFunction2()">
                            <input type="button" name="item-2" id="item-2" hidden>
                            <label for="item-2"><img src="img/red-bin.png" alt=""></label>
                        </li>
                        <li class="itens-3" onclick="myFunction3()">
                            <input type="button" name="item-3" id="item-3" hidden>
                            <label for="item-3"><img src="img/green-bin.png" alt=""></label>
                        </li>
                        <li class="itens-4" onclick="myFunction4()">
                            <input type="button" name="item-4" id="item-4" hidden>
                            <label for="item-4"><img src="img/yellow-bin.png" alt=""></label>
                        </li>
                    </ul>
                </div>

                <!--Campo onde todas as opções de compra do produto ficara-->
                <div class="comprar-campos">
                    <p class="title"><!--titulo do produto-->
                        <?= $x['nome']?>
                    </p>
                    <ul class="avaliation"><!--Local de avalição do produto-->
                        <li class="star-icon ativo" data-avaliacao="1"></li>
                        <li class="star-icon" data-avaliacao="2"></li>
                        <li class="star-icon" data-avaliacao="3"></li>
                        <li class="star-icon" data-avaliacao="4"></li>
                        <li class="star-icon" data-avaliacao="5"></li>
                        <p>(1485 avalições)</p>
                    </ul>
                    <div class="prices">
                        <p class="discount"> R$1900,00</p>
                        <p class="price">R$1500,00</p>
                        <p class="discount-perc">27% OFF</p>
                    </div>
                    <div class="opcoes">
                        <ul>
                            <li><img src="img/ex.jpg" alt=""></li>
                            <li><img src="img/ex.jpg" alt=""></li>
                            <li><img src="img/ex.jpg" alt=""></li>
                            <li><img src="img/ex.jpg" alt=""></li>

                            <li><img src="img/ex.jpg" alt=""></li>

                            <li><img src="img/ex.jpg" alt=""></li>
                        </ul>
                    </div>
                    <div class="btn">
                        <button>comprar</button>
                    </div>
                </div>
            </section>
            <hr>
            <div class="area-abaixo">
                <div class="descricao-produto">
                    <p class="title">
                        descrição do produto
                    </p>
                    <div class="campo-descricao">

                    </div>
                </div>
                <div class="mais-produtos">
                    <p class="title">
                        Deseja Mais Produtos
                    </p>
                    <a href="venda.html">
                        <div class="card">
                            <div class="card-img-main">
                                <img src="img/ex.jpg" alt="">
                            </div>
                            <div class="card-favorite-icon"><img src="img/free-favourite-icon-2765-thumb.png" alt="">
                            </div>
                            <p class="card-title">PRODUTO EXEMPLO</p>
                            <div class="price">
                                <p class="card-price-discount">R$3200,00 </p>
                                <p class="card-price">R$1600,00 <b>43% OFF</b></p>
                                <p class="card-price-parcelas">10x de R$160,00</p>
                                <div class="card-avaliation">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                </div>
                            </div>
                        </div>
                    </a><!--Card de compra-->
                    <a href="venda.html">
                        <div class="card">
                            <div class="card-img-main">
                                <img src="img/ex.jpg" alt="">
                            </div>
                            <div class="card-favorite-icon"><img src="img/free-favourite-icon-2765-thumb.png" alt="">
                            </div>
                            <p class="card-title">PRODUTO EXEMPLO</p>
                            <div class="price">
                                <p class="card-price-discount">R$3200,00 </p>
                                <p class="card-price">R$1600,00 <b>43% OFF</b></p>
                                <p class="card-price-parcelas">10x de R$160,00</p>
                                <div class="card-avaliation">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                    <img src="img/free-favourite-icon-2765-thumb.png" alt="">
                                </div>
                            </div>
                        </div>
                    </a><!--Card de compra-->

                </div>
            </div>
            <div class="comentarios">

            </div>
        </div>
    </div>
    <script src="js/js.js"></script>
</body>

</html>