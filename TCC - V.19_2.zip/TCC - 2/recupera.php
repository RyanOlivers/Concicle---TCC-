<?php
//Conectando ao banco
include_once('conecta.php');

if (isset($_POST['enviar'])) {
    //traz as variáveis do formulário
    $codigo = $_POST['codigo'];

    //Script de uma busca em uma tabela no Banco de Dados
    $sql = "SELECT titulo, arquivo FROM prodImagem WHERE idImagem = '$codigo' ";

    // executando instrução SQL
    $instrucao = mysqli_query($conexao, $sql);

    $registro = mysqli_fetch_array($instrucao);

    //concluindo operação

    //testa resultados
    //var_dump ($registro);

}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Manipulando arquivos</title>
    <meta charset="utf-8" />
</head>

<body>
    <form action="" method="POST" enctype="multipart/form-data">
        <label>Código: </label><br />
        <input type="number" name="codigo" required /><br />
        <input type="submit" value="Enviar" name="enviar">
        <input type="reset" value="Apagar">
    </form>
    <br />
    <hr />

    <label>Título:<label>
            <p> <?= $registro['titulo']; ?></p>
            <br />
            <a href="<?= $registro['arquivo']; ?>">
                <img src="<?= $registro['arquivo']; ?>" height="350px" />
            </a>

            <br> <a href='http://localhost/php/Cod-IMAGENS/Cod-FEITO'>Voltar</a>
</body>

</html>