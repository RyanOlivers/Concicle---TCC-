document.getElementById('toggleBtn').addEventListener('click', toggleCarrinho);
document.getElementById('finalizarBtn').addEventListener('click', finalizarCompra);
document.getElementById('adicionarBtn').addEventListener('click', adicionarProduto);

function toggleCarrinho() {
  var boxCarrinho = document.getElementById('boxCarrinho');
  boxCarrinho.classList.toggle('open');
}

function finalizarCompra() {
  // Lógica para finalizar a compra
}

function adicionarProduto() {
  var carrinho = document.getElementById('carrinho');
  var novoProduto = document.createElement('div');
  novoProduto.classList.add('produto');

  var imagemProduto = document.createElement('img');
  imagemProduto.classList.add('imagem-produto');
  imagemProduto.src = 'img/miranha.jfif';
  imagemProduto.alt = 'Imagem do Produto';
  novoProduto.appendChild(imagemProduto);

  var infoProduto = document.createElement('div');
  infoProduto.classList.add('info-produto');

  var nomeProduto = document.createElement('span');
  nomeProduto.classList.add('nome-produto');
  nomeProduto.innerText = 'Nome do Produto';
  infoProduto.appendChild(nomeProduto);

  var precoQuantidadeContainer = document.createElement('div');
  precoQuantidadeContainer.classList.add('preco-quantidade-container');

  var precoProduto = document.createElement('span');
  precoProduto.classList.add('preco-produto');
  precoProduto.innerText = 'R$ 0,00';
  precoQuantidadeContainer.appendChild(precoProduto);

  var quantidadeProduto = document.createElement('span');
  quantidadeProduto.classList.add('quantidade-produto');
  quantidadeProduto.innerText = 'Quantidade: 1';
  precoQuantidadeContainer.appendChild(quantidadeProduto);

  infoProduto.appendChild(precoQuantidadeContainer);

  var removerBtn = document.createElement('button');
  removerBtn.innerText = 'X';
  removerBtn.className = 'remover-produto';
  removerBtn.addEventListener('click', removerProduto);
  infoProduto.appendChild(removerBtn);

  novoProduto.appendChild(infoProduto);

  carrinho.appendChild(novoProduto);
}

function removerProduto(event) {
  var produto = event.target.parentNode.parentNode;
  produto.parentNode.removeChild(produto);
}
