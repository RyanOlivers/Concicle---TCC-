<?php


//Conectando ao banco
include_once('conexao/conexao.php');
//Tabela no BD
$tabela = "imagens";
//define campos do insert
$campos = "nome_imagem,tamanho_imagem,tipo_imagem, caminho_imagem";
//define o diretorio para envio de arquivos
$diretorio = "uploads/";

// define a zona de tempo a ser utilizada.
date_default_timezone_set('America/Sao_Paulo');

if (isset($_POST['enviar'])) {
    //traz as variáveis do formulário
    $titulo = $_POST['titulo'];
    $upload = 0;

    //echo "<pre>";
    //var_dump($_FILES);
    //echo "</pre>";

    //recupera a extensao do arquivo
    $extensao = strtolower(substr($_FILES['arquivo']["name"], -4));
    $size = $_FILES['arquivo']["size"];
    //define o nome do arquivo
    //configura no formato yyyy-mm-dd_hh:mm:ss
    $novo_nome = $titulo . $extensao;

    $verificar = "uploads/" . $novo_nome;

    $arquivo = $diretorio . $novo_nome;

    // Formatos de imagem permitidos
    $allowedFormats = array("jpg", "jpeg", "png", "webp");
    switch ($extensao) {
        case '.jpg':
            $upload = 1;
            break;
        case '.jpeg':
            $upload = 1;
            break;
        case '.png':
            $upload = 1;
            break;
        case '.webp':
            $upload = 1;
            break;
        default:
            $upload = 0;
            break;
    }


    //Script para inserir o caminho do arquivo ao BD
    $sql = "INSERT INTO $tabela ($campos) 
			VALUES ('$titulo','$arquivo')";

    //concluindo operação
    // Verificar se o arquivo já existe
    if (file_exists($verificar)) {
        $uploadOk = 0;
    } elseif ($upload == 1) {
        //efetua o upload para repositório de imagens
        move_uploaded_file($_FILES['arquivo']["tmp_name"], $arquivo);
        // executando instrução SQL
        $instrucao = mysqli_query($conexao, $sql);

        if (!$instrucao) {
            die(' Query Inválida: ' . mysqli_error($conexao));
            echo 'Falha ao enviar arquivo!';
        } else {
            mysqli_close($conexao);
            echo 'Arquivo enviado com sucesso!';
            echo "<br> <a href='http://localhost/PHP/Cod-IMAGENS/Cod-FEITO'>Voltar para Local</a>";
            echo "<br> <a href='http://localhost/PHP/Cod-IMAGENS/Cod-FEITO/cadastraIMG.php'>Colocar mais uma IMG</a>";
            echo "<br> <a href='http://localhost/PHP/Cod-IMAGENS/Cod-FEITO/recupera.php'>Ver Imagem</a>";
            exit;
        }
    } elseif ($upload == 0) {
        echo "Desculpe, a imagem já existe no servidor. <br>";
        echo "Ou esse tipo de arquivo não é permitido";
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <title>Manipulando arquivos</title>
    <meta charset="utf-8" />
</head>

<body>
    <form action="" method="POST" enctype="multipart/form-data">
        <label>Título: </label><br />
        <input type="text" name="titulo" /><br />
        <br>
        <label>Selecione o arquivo: <br />
            <input type="file" name="arquivo" size="45" accept="image/*" required /></label> <br />
        <input type="submit" value="Enviar" name="enviar">
        <input type="reset" value="Apagar">
    </form>
    <br> <br> <a href='http://localhost/php/Cod-IMAGENS/Cod-FEITO'>Voltar</a>
</body>

</html>