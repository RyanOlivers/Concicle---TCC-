var menu = document.getElementById("menu");

window.addEventListener("scroll", function() {
  if (window.pageYOffset > (window.innerHeight * 0.5)) {
    menu.classList.add("hide-menu");
  } else {
    menu.classList.remove("hide-menu");
  }
});

// Verificar a posição inicial da janela e ocultar o menu, se necessário
if (window.pageYOffset > (window.innerHeight * 0.1)) {
  menu.classList.add("hide-menu");
}

menu.addEventListener("mouseenter", function() {
  menu.classList.remove("hide-menu");
});

menu.addEventListener("mouseleave", function() {
  if (window.pageYOffset > (window.innerHeight * 0.1)) {
    menu.classList.add("hide-menu");
  }
});
window.addEventListener("scroll", function() {
  if (window.pageYOffset > (window.innerHeight * 0.1)) { /* 10vh corresponde a 10% da altura da janela de visualização */
    menu.classList.add("dark");
  } else {
    menu.classList.remove("dark");
  }
});
