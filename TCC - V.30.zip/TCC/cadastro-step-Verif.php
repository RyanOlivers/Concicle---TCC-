<?php
include('conexao/conexao.php');

$OK = $_GET["Ok"];
if (isset($_GET["Ok"]) and $OK == "success") {
    $cargo =  $_SESSION['cargo'];
    if ($cargo == 1) {
        // Obtenha os dados do usuário da sessão
        $nome = $_SESSION['nome_user'];
        $sobrenome = $_SESSION['sobrenome_user'];
        $email = $_SESSION['email'];
        $cpf = $_SESSION['cpf'];
        $ddd = $_SESSION['DDD'];
        $tel = $_SESSION['tel'];
        $cep = $_SESSION['cep'];
        $bairro = $_SESSION['bairro'];
        $cidade = $_SESSION['cidade'];
        $estado = $_SESSION['estado'];
        $endereco = $_SESSION['endereco'];
        $num = $_SESSION['num'];
        $complemento = $_SESSION['complemento'];
        $senha = $_SESSION['senha'];

        // Inserir endereço
        $sql_endereco = "INSERT INTO endereco (CEP, UF, rua, bairro, cidade, num_casa, complemento) VALUES ('$cep', '$estado', '$endereco', '$bairro', '$cidade', '$num', '$complemento')";
        $res_endereco = $conn->query($sql_endereco) or die("Falha: " . $conn->error);

        // Inserir usuário
        $sql = "INSERT INTO usuario (nome, sobrenome, senha, email, CPF, cargo) VALUES ('$nome', '$sobrenome', '$senha', '$email', '$cpf', '$cargo')";
        $res = $conn->query($sql) or die("Falha: " . $conn->error);

        // Obter o ID do usuário recém-inserido
        $id_user = $conn->insert_id;

        // Inserir contato
        $sql_contato = "INSERT INTO contato (ID_usuario, tel_fixo, DDD, tel_celular) VALUES ('$id_user', '', $ddd , '$tel')";
        $res_contato = $conn->query($sql_contato) or die("Falha: " . $conn->error);

        // Inserir relação entre usuário e endereço
        $sql_popula_tudo = "INSERT INTO user_ender (ID_usuario, ID_endereco) VALUES ('$id_user', LAST_INSERT_ID())";
        $res_popula_tudo = $conn->query($sql_popula_tudo) or die("Falha: " . $conn->error);
        // header("location: cadastro-step-7.php?id=$id_user.php");
    } elseif ($cargo == 2) {
        // Obtenha os dados do usuário da sessão
        $nome = $_SESSION['nome_user'];
        $sobrenome = $_SESSION['sobrenome_user'];
        $email = $_SESSION['email'];
        $cpf = $_SESSION['cpf'];
        $tel = $_SESSION['tel'];
        $cep = $_SESSION['cep'];
        $ddd = $_SESSION['DDD'];
        $bairro = $_SESSION['bairro'];
        $cidade = $_SESSION['cidade'];
        $estado = $_SESSION['estado'];
        $endereco = $_SESSION['endereco'];
        $num = $_SESSION['num'];
        $complemento = $_SESSION['complemento'];
        $senha = $_SESSION['senha'];

        // Inserir endereço
        $sql_endereco = "INSERT INTO endereco (CEP, UF, rua, bairro, cidade, num_casa, complemento) VALUES ('$cep', '$estado', '$endereco', '$bairro', '$cidade', '$num', '$complemento')";
        $res_endereco = $conn->query($sql_endereco) or die("Falha: " . $conn->error);

        // Inserir usuário
        $sql = "INSERT INTO usuario (nome, sobrenome, senha, email, CPF, cargo) VALUES ('$nome', '$sobrenome', '$senha', '$email', '$cpf', '$cargo')";
        $res = $conn->query($sql) or die("Falha: " . $conn->error);

        // Obter o ID do usuário recém-inserido
        $id_user = $conn->insert_id;

        // Inserir contato
        $sql_contato = "INSERT INTO contato (ID_usuario, tel_fixo, DDD, tel_celular) VALUES ('$id_user', '', $ddd , '$tel')";
        $res_contato = $conn->query($sql_contato) or die("Falha: " . $conn->error);

        // Inserir relação entre usuário e endereço
        $sql_popula_tudo = "INSERT INTO user_ender (ID_usuario, ID_endereco) VALUES ('$id_user', LAST_INSERT_ID())";
        $res_popula_tudo = $conn->query($sql_popula_tudo) or die("Falha: " . $conn->error);
        header("location: cadastro-step-7.php?id=$id_user");
    }
    //
} else {
    header("location: cadastro-step-1.php");
}
