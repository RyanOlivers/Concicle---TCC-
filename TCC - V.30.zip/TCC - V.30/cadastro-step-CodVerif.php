<?php
include('conexao/conexao.php');
//Recebendo os números inseridos
$codigo = $_SESSION['codigoUSER'];
if (isset($_POST["Verificar"])) {

    $cod1 = $_POST['cod1'];
    $cod2 = $_POST['cod2'];
    $cod3 = $_POST['cod3'];
    $cod4 = $_POST['cod4'];
    //Recendo o id e o código gerado para o usuário
    //Código inserido pelo usuário
    $codInserido = $cod1 . $cod2 . $cod3 . $cod4;

    if (!empty($codInserido)) {
        // Checa se o código inserido é igual ao código gerado
        if ($codInserido == $codigo) {
            //echo $codigo;
            $errorOK = "success";
            $_SESSION["OK"] = $errorOK;
            $Ok = $_SESSION["OK"];
            header("location: cadastro-step-Verif.php?Ok=$Ok");
        } else {
            $errorFAIL = "Código errado!";
        }
    } else {
        $errorFAIL = "Insira o código completo.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/cadastro.css">
    <link rel="stylesheet" href="css/menu.css">
    <title>CONCICLE | Cadastro</title>
</head>

<body>
    <div id="container">
        <nav>
            <ul class="a">
                <li class="logotipo">
                    <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li>
                            <a href='login.php' class='cursor'>Login</a>
                        </li>
                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <main class="bg">
            <section class="login">
                <!-- <header class="header-login">
                    <h1> Conscientize, Recicle & Receba </h1>
                    <h2> Faça parte dessa equipe e mude o mundo! </h2>
                </header> -->
                <main class="main-cadastro">
                    <h1 class="main-title">ÚLTIMO PASSOU!</h1>
                    <h2 class="main-sub-title">Confirme seu email: <?=$_SESSION['email']?>, e poderar ajudar o meio ambiente!</h2>
                    <form action="" method="post" autocomplete="off" class="fields-input">
                        <div>
                            <input type="number" name="cod1" class="cod-field" placeholder="0" maxlength="1" min="0" max="9" required
                                onpaste="false">
                            <input type="number" name="cod2" class="cod-field" placeholder="0" maxlength="1" min="0" max="9" required
                                onpaste="false">
                            <input type="number" name="cod3" class="cod-field" placeholder="0" maxlength="1" min="0" max="9" required
                                onpaste="false">
                            <input type="number" name="cod4" class="cod-field" placeholder="0" maxlength="1" min="0" max="9" required
                                onpaste="false">
                        </div>
                        <div class="submit">
                            <input type="submit" name="Verificar" value="Verificar" class="button">
                        </div>
                        <p class="error"><?= $errorFAIL ?></p>
                    </form>
                </main>
                <ul class='opcoes'>
                    <li class="disselect"></li>
                    <li class="disselect"></li>
                    <li class="select"></li>

                </ul>
            </section>
        </main>
    </div>
</body>
<script src="js/js.js"> </script>
<script src="js/verif.js"> </script>
<script src="js/cpf.js"> </script>

</html>