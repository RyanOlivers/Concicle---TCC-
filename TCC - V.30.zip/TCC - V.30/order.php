<?php
include_once("conexao/conexao.php");

$id_user = $_GET['id_user'];
$id_prod = $_GET['id_prod'];
$quant = $_GET['quant'];
$endpoint = 'https://sandbox.api.pagseguro.com/orders';
$token = '3A03DA58CA5246BA9212272113A96C32';

$query = "SELECT * FROM usuario WHERE ID_usuario = $id_user";
$result = $conn->query($query)->fetch_assoc();

$query_cont = "SELECT * FROM contato WHERE ID_usuario = $id_user";
$result_cont = $conn->query($query_cont)->fetch_assoc();

$query_ender = "SELECT * FROM endereco WHERE ID_endereco = $id_user";
$result_ender = $conn->query($query_ender)->fetch_assoc();

$query_prod = "SELECT * FROM produto WHERE ID_prod = $id_prod";
$result_prod = $conn->query($query_prod)->fetch_assoc();

$id_pedido = "ORDER_" . $result_prod['ID_prod'] . mt_rand(11111111, 99999999);

$body =
    [
        "reference_id" => $id_pedido,
        // Dados do cliente
        "customer" => [
            "name" => $result['nome'] . " " . $result['sobrenome'],
            "email" => $result['email'],
            "tax_id" => $result['CPF'],

            // Telefone do cliente
            "phones" => [
                [
                    "country" => "55",
                    "area" => $result_cont['DDD'],
                    "number" => $result_cont['tel_celular'],
                    "type" => "MOBILE"
                ]
            ]
        ],
        // Dados do produto
        "items" => [
            [
                "name" => $result_prod['nome'],
                "quantity" => $result_prod['quantidade'],
                // Valor do produto no site;
                "unit_amount" => intval($result_prod['preco'])
            ]
        ],
        "qr_codes" => [
            [
                "amount" => [
                    // Definir valor da Transação aqui;
                    "value" => ($result_prod['preco'] * 100) 
                ],
                "expiration_date" => "2023-12-29T20:15:59-03:00",
            ]
        ],
        // Dados da entrega/localização
        "shipping" => [
            "address" => [
                "street" => $result_ender['rua'],
                "number" => $result_ender['num_casa'],
                "complement" => $result_ender['complemento'],
                "locality" => $result_ender['bairro'],
                "city" => $result_ender['cidade'],
                "region_code" => $result_ender['UF'],
                "country" => "BRA",
                "postal_code" => $result_ender['CEP']
            ]
        ],
        // URL onde será enviado os dados do pagamento
        "notification_urls" => [
            "https://webhook.site/e69f08a3-5298-45fa-82fb-b0d61db46cb2",
            // 
        ]
    ];

$curl = curl_init();
curl_setopt($curl, CURLOPT_URL, $endpoint);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($body));
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
curl_setopt($curl, CURLOPT_CAINFO, 'C:/xampp/htdocs/TCC/cacert.pem');
curl_setopt($curl, CURLOPT_HTTPHEADER, [
    'Content-Type:application/json',
    'Authorization: Bearer ' . $token
]);

$response = curl_exec($curl);
$error = curl_error($curl);

curl_close($curl);

if ($error) {
    var_dump($error);
    die();
}

$data = json_decode($response, true);
$_SESSION['QR_CODE'] = $data['qr_codes'][0]['id'];

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONCICLE | Pagamento</title>
    <link rel="shortcut icon" href="img/LOGO.png" type="image/x-icon">
    <link rel="stylesheet" href="css/menu.css">
    <link rel="stylesheet" href="css/order.css">
</head>

<body>
    <div id="container">
        <!--menu-->
        <nav>
            <ul class="a">
                <li class="logotipo">
                    <a href="index.php"><img src="img/LOGO_PRINCIPAL_2.png" alt="logo" srcset=""></a>
                </li>
                <li class="usuario">
                    <ul>
                        <li class="li-pai">
                            <?php
                            //caso ele logado no menu mostrar o perfil dele
                            if (isset($_SESSION['nome']) && $_SESSION['nome'] != '') {
                                echo "<p class='cursor dropdown-arrow'>" . $_SESSION['nome'] . "</p>";
                                ?>

                                <ul class='sub-menus'>
                                    <li class="perfil">
                                        <a href="perfil.php">
                                            <?php
                                            $id_usuario = $_SESSION['id'];
                                            $sql = $conn->query("SELECT ID_img, nome_imagem, tamanho_imagem, tipo_imagem, caminho_imagem FROM imagens WHERE ID_user = '$id_usuario'")->fetch_assoc();
                                            echo "<img src='{$sql['caminho_imagem']}' alt=''>";

                                            ?>
                                            <div class="sub-text">
                                                <p class="p-ola"> Olá </p>
                                                <p class="p-name">
                                                    <?= $_SESSION['nome'] ?>
                                                </p>
                                            </div>
                                        </a>
                                    </li>

                                    <li class="perfil-bloco"> <a href='perfil.php'> <img src="img/perfil.svg" alt=""
                                                srcset="">
                                            Meu perfil </a>
                                        <a href='favoritos.php'> <img src="img/favorite.svg" alt="" srcset=""> Favoritos
                                        </a>
                                        <a href='#'> <img src="img/history.svg" alt="" srcset=""> Histórico/Compras
                                        </a>
                                    </li>
                                    <li class="vender-bloco"><a href='vender.php'> <img src="img/sell.svg" alt="" srcset="">
                                            Vender</a></li>
                                    <li class="ajuda-bloco"><a href='#'> <img src="img/question.svg" alt="" srcset="">
                                            Perguntas</a></li>
                                    <li class="sair-button"><a href='logout.php'> <img src="img/logout.svg" alt=""
                                                srcset="">
                                            sair </a></li>
                                </ul>

                                <?php
                            } else {
                                echo "<a href='login.php' class='cursor'> Login </a>";
                            }
                            ?>
                        </li>
                        <li class="sobre"><a href="Sobre.php">Sobre</a></li>
                    </ul>
                </li>
            </ul>
        </nav>
        <main class='tudo'>
            <main>
                <section class="qr_code">
                    <h1>Escaneie o QR code abaixo:</h1>
                    <p>Nos não reservamos estoque até que o pagamento seja aprovado. Não perca tempo!</p>
                    <p>Valor: R$ <?= $data['qr_codes'][0]['amount']['value'] / 100 . ',00'?> </p>
                    <?php if ($data): ?>
                        <img class="img_qr_code" src="<?php echo $data['qr_codes'][0]['links'][0]['href'] ?>" alt="">
                    <?php endif; ?>
                </section>
                
                <section class="dados">
                    <!-- id do pedido -->
                    <h1>dados do pedido</h1>
                    <!-- Detalhes do Produto -->
                    <ul>
                        <li>
                            <p>pedido:</p> <span><?= $data['id']?></span>
                        </li>
                        <li>
                            <p>Produto:</p> <span><?= $data['items'][0]['name'] ?></span>
                        </li>
                        <li>
                            <p>Valor: R$ </p> <span><?= $data['qr_codes'][0]['amount']['value'] / 100 . ',00' ?><span>    
                        </li>
                    </ul>
                    <!-- Detalhes da Entrega -->
                    <h2>Dados da entrega:</h2>
                    <ul>
                        <li>
                            <p>Endereço:</p><span><?= $data['shipping']['address']['street'] . ', ' . $data['shipping']['address']['number'] . '- ' . $data['shipping']['address']['locality'] ?></span>
                        </li>
                        <li>
                            <p>CEP:</p><span><?= $data['shipping']['address']['postal_code']?> <a href='#'>alterar</a>  </span>
                            
                        </li>
                    </ul>
                    <form action="" method="post">
                        <h2>Caso ja tenha feito o pagamento clique no botão de voltar</h2>
                        <button name="back" type="submit">
                            Voltar
                        </button>
                    </form>
                    <?php
                        if (isset($_POST['back'])) {

                        ?>
                        <script>
                            window.location = "index.php";
                        </script>
                        <?php
                        }
                        // echo "<pre>";
                        // echo "<p style='color: #000'>";
                        // var_dump($data);
                        // echo "</p>";
                        // echo "</pre>";
                    ?>
                </section>
            </main>
        </main>

    </div>
    <script src="js/js.js"></script>
</body>

</html>